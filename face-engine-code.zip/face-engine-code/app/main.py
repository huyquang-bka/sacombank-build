from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.api.v1.api import router as api_router
from app.core.config import app_config
from app.core.model_manager import (
    insightface_model_manager,
    face_mask_model_manager,
    face_quality_model_manager,
)
from app.core.local_db import local_db_manager
import asyncio
from contextlib import asynccontextmanager
from datetime import datetime


async def periodic_sync():
    """Sync persons data every TIME_PER_SYNC minutes"""
    while True:
        try:
            # Wait for the configured sync interval
            minutes_to_wait = app_config.TIME_PER_SYNC
            seconds_to_wait = minutes_to_wait * 60

            print(
                f"Next sync scheduled in {minutes_to_wait} minutes ({seconds_to_wait} seconds)"
            )

            # Wait until next sync time
            await asyncio.sleep(seconds_to_wait)

            # Perform sync
            print(
                f"Starting periodic sync at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
            )
            await local_db_manager.sync_persons()
            print(
                f"Periodic sync completed at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
            )

        except Exception as e:
            print(f"Error in periodic sync: {str(e)}")
            # Wait 1 minute before retrying if there's an error
            await asyncio.sleep(60)


@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup: load the models
    await insightface_model_manager.load_model()
    await face_mask_model_manager.load_model()
    await face_quality_model_manager.load_model()

    # Initial sync based on RELOAD_DB config
    if app_config.RELOAD_DB:
        try:
            print("Starting initial sync...")
            await local_db_manager.sync_persons()
            print("Initial sync completed successfully")
        except Exception as e:
            print(f"Initial sync failed: {str(e)}")
            print("Continuing without initial sync")
    else:
        print("Skipping initial sync (RELOAD_DB=false)")

    # Start periodic sync
    asyncio.create_task(periodic_sync())

    yield

    # Shutdown: clean up the models
    await insightface_model_manager.close_model()
    await face_mask_model_manager.close_model()
    await face_quality_model_manager.close_model()


app = FastAPI(
    title=app_config.APP_NAME, version=app_config.APP_VERSION, lifespan=lifespan
)

# Set up CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=app_config.ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include API router
app.include_router(api_router, prefix=app_config.API_V1_STR)

if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="0.0.0.0", port=62070)
