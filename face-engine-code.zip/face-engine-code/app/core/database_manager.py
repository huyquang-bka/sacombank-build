from datetime import datetime
from typing import List, Optional, Tuple
import asyncio
import numpy as np
import json
import os
import psycopg2
from app.core.config import app_config
from app.utils.helpers import decode_embedding
from app.utils.helpers import cosine_similarity
from app.schemas.analyze.search_face import FaceResult
from app.schemas.analyze.search_event import EventResult
from app.core.local_db import local_db_manager


class DatabaseManager:
    def __init__(self):
        self._lock = asyncio.Lock()
        self.conn_params = {
            "host": app_config.DATABASE_URL,
            "port": app_config.DATABASE_PORT,
            "dbname": app_config.DATABASE_NAME,
            "user": app_config.DATABASE_USERNAME,
            "password": app_config.DATABASE_PASSWORD,
            "options": f"-c search_path={app_config.DATABASE_SCHEMA}",
        }
        self.persons = []
        self.face_features_matrix = None
        self.person_indices = []
        self.hard_to_recognize_codes = set()
        self.use_gpu = False
        print("Chỉ sử dụng CPU (numpy vectorization) cho search")

        # Load hard to recognize persons
        self._load_hard_to_recognize_persons()

    @staticmethod
    def _quote_identifier(identifier: str) -> str:
        return '"' + identifier.replace('"', '""') + '"'

    def _qualified_table(self, table_name: str) -> str:
        return (
            f"{self._quote_identifier(app_config.DATABASE_SCHEMA)}."
            f"{self._quote_identifier(table_name)}"
        )

    def _load_hard_to_recognize_persons(self):
        """Load list of hard to recognize persons from JSON file."""
        try:
            config_path = os.path.join(
                "resources", "config", "hard_to_recognize.json")
            if os.path.exists(config_path):
                with open(config_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    hard_persons = data.get("hard_to_recognize_persons", [])
                    self.hard_to_recognize_codes = {
                        person["personCode"] for person in hard_persons}
                    print(
                        f"Loaded {len(self.hard_to_recognize_codes)} hard to recognize persons: {list(self.hard_to_recognize_codes)}")
            else:
                print(
                    f"Hard to recognize config file not found at {config_path}")
        except Exception as e:
            print(f"Error loading hard to recognize persons: {e}")

    async def load_persons(self):
        """
        Load person data from local SQLite database and prepare for vectorized search.

        Returns:
            List of person records as dictionaries
        """
        async with self._lock:
            try:
                self.persons = await local_db_manager.get_all_persons()

                if not self.persons:
                    self.face_features_matrix = None
                    self.person_indices = []
                    print("No persons found in database")
                    return []

                # Decode embeddings and prepare for vectorized search
                face_features = []
                self.person_indices = []
                print("Total person processing: ", len(self.persons))
                for i, person in enumerate(self.persons):
                    try:
                        face_feature = decode_embedding(
                            person['faceFeature'], app_config.SECRET_KEY)
                        if face_feature.shape[0] != 512:
                            print(
                                f"Removing person {person['personId']}: embedding dimension {face_feature.shape[0]} != 512")
                            continue

                        feature_norm = np.linalg.norm(face_feature)
                        if feature_norm <= 0:
                            print(
                                f"Removing person {person['personId']}: zero-norm embedding")
                            continue

                        normalized_feature = (
                            face_feature / feature_norm).astype(np.float32)
                        face_features.append(normalized_feature)
                        self.person_indices.append(i)
                        person['FaceFeature'] = normalized_feature
                    except Exception as e:
                        print(
                            f"Error decoding embedding for person {person['personId']}: {e}")
                        continue

                if face_features:
                    # Matrix is pre-normalized during load.
                    self.face_features_matrix = np.array(
                        face_features, dtype=np.float32)

                    print(
                        f"Loaded {len(self.persons)} persons from local database")
                    print(
                        f"Prepared {len(face_features)} normalized face features for vectorized search")
                else:
                    self.face_features_matrix = None
                    self.person_indices = []
                    print("No valid face features found")

                return self.persons
            except Exception as e:
                print(f"Error loading persons from local database: {e}")
                return []

    def _compute_similarities_vectorized(self, face_embedding: np.ndarray, compIds: Optional[List[int]] = None) -> Tuple[np.ndarray, List[int]]:
        """
        Compute similarities using vectorized operations.

        Args:
            face_embedding: Face feature vector to search for
            compIds: Optional list of company IDs to filter by

        Returns:
            Tuple of (similarities, valid_matrix_indices)
            - similarities: Array of similarity scores
            - valid_matrix_indices: Indices into face_features_matrix (not person indices)
        """
        if self.face_features_matrix is None:
            return np.array([]), []

        # Get all matrix indices (0 to len(person_indices)-1)
        all_matrix_indices = list(range(len(self.person_indices)))

        if compIds:
            # Filter: find matrix indices where corresponding person has compId in compIds
            # self.person_indices[i] gives the person index for matrix index i
            valid_matrix_indices = [
                i for i in all_matrix_indices
                if self.persons[self.person_indices[i]]['compId'] in compIds
            ]
        else:
            valid_matrix_indices = all_matrix_indices

        if not valid_matrix_indices:
            return np.array([]), []

        # CPU computation with numpy vectorization only
        # valid_matrix_indices are indices into face_features_matrix
        filtered_features = self.face_features_matrix[valid_matrix_indices]

        # Database matrix is pre-normalized during load.
        face_embedding_norm_value = np.linalg.norm(face_embedding)
        if face_embedding_norm_value <= 0:
            return np.array([]), []
        face_embedding_norm = (
            face_embedding / face_embedding_norm_value).astype(np.float32, copy=False)

        # Compute dot product (cosine similarity)
        similarities = np.dot(filtered_features, face_embedding_norm)
        return similarities, valid_matrix_indices

    async def search_person(self, face_embedding: np.ndarray, threshold: float = 0.5, compIds: Optional[List[int]] = None) -> Tuple[List[FaceResult], Optional[FaceResult]]:
        """
        Search for matching faces in the database using vectorized cosine similarity.

        Args:
            face_embedding: Face feature vector to search for
            threshold: Similarity threshold (default: 0.5)

        Returns:
            Tuple of (recognized_persons, nearest_person) - only returns the best match
        """
        if not self.persons:
            print("Waiting for persons to load from local database")
            await self.load_persons()

        if not self.persons or self.face_features_matrix is None:
            print("No persons loaded or face features not prepared")
            return [], None

        # Validate embedding dimension
        if not self.validate_embedding(face_embedding):
            print("Invalid embedding dimension. Expected 512-dimensional embedding.")
            return [], None
        threshold /= 2
        similarity_threshold = app_config.SIMILARITY_THRESHOLD / 2
        try:
            # Compute similarities using vectorized operations
            # Returns: (similarities, valid_matrix_indices)
            # valid_matrix_indices are indices into face_features_matrix
            similarities, valid_matrix_indices = self._compute_similarities_vectorized(
                face_embedding, compIds)
            if len(similarities) == 0:
                print("No valid persons found matching criteria")
                return [], None

            # Find the best similarity using numpy argmax
            # best_similarity_index is the index in the filtered similarities array
            best_similarity_index = int(np.argmax(similarities))
            best_similarity = float(similarities[best_similarity_index])

            # Map back to person index:
            # 1. valid_matrix_indices[best_similarity_index] -> index in face_features_matrix
            # 2. self.person_indices[matrix_idx] -> index in self.persons
            best_matrix_idx = valid_matrix_indices[best_similarity_index]
            best_person_idx = self.person_indices[best_matrix_idx]
            best_person = self.persons[best_person_idx]

            nearest_person = FaceResult(
                personId=best_person['personId'],
                personCode=best_person['personCode'],
                fullname=best_person['fullname'],
                scoreMatching=best_similarity
            )

            # Check if the best match is a hard to recognize person
            if nearest_person and nearest_person.personCode in self.hard_to_recognize_codes:
                print(
                    f"Hard to recognize person detected: {nearest_person.fullname} ({nearest_person.personCode})")
                # Use fixed threshold of 0.7 for hard to recognize persons
                hard_threshold = 0.35
                if nearest_person.scoreMatching >= hard_threshold:
                    nearest_person.scoreMatching = min(
                        nearest_person.scoreMatching * 2, 1)
                    print(
                        f"Found hard to recognize person: {nearest_person.fullname} with score {nearest_person.scoreMatching:.3f}")
                    return [nearest_person], nearest_person
                else:
                    print(
                        f"Hard to recognize person {nearest_person.fullname} below threshold {hard_threshold}")
                    return [], None

            # Return only the best match if it meets threshold for normal persons
            if nearest_person and nearest_person.scoreMatching >= threshold:
                nearest_person.scoreMatching = min(
                    nearest_person.scoreMatching * 2, 1)
                print(
                    f"Found best match: {nearest_person.fullname} with score {nearest_person.scoreMatching:.3f}")
                return [nearest_person], nearest_person
            if nearest_person and nearest_person.scoreMatching >= similarity_threshold:
                nearest_person.scoreMatching = min(
                    nearest_person.scoreMatching * 2, 1)
                print(
                    f"Found nearest match: {nearest_person.fullname} with score {nearest_person.scoreMatching:.3f} but below threshold {threshold}")
                return [], nearest_person
            else:
                print(
                    f"No person found above threshold {threshold}, only {nearest_person.fullname} with score {nearest_person.scoreMatching}")
                return [], None

        except Exception as e:
            print(f"Error in vectorized search: {e}")
            # Fallback to original method if vectorized search fails
            return await self._search_person_fallback(face_embedding, threshold)

    async def _search_person_fallback(self, face_embedding: np.ndarray, threshold: float = 0.5) -> Tuple[List[FaceResult], Optional[FaceResult]]:
        """
        Fallback search method using original loop-based approach.
        """
        results: List[FaceResult] = []
        nearest_person = None
        for person in self.persons:
            try:
                face_feature = person.get('FaceFeature')
                similarity = cosine_similarity(face_embedding, face_feature)
                results.append(FaceResult(
                    personId=person['personId'],
                    personCode=person['personCode'],
                    fullname=person['fullname'],
                    scoreMatching=float(similarity)
                ))
            except Exception as e:
                print(f"Error processing person {person['personId']}: {e}")
                continue

        # Sort by similarity in descending order
        results.sort(key=lambda x: x.scoreMatching, reverse=True)
        if not results:
            print("No results found")
            return [], None

        nearest_person = results[0]

        # Check if the best match is a hard to recognize person
        if nearest_person.personCode in self.hard_to_recognize_codes:
            print(
                f"Hard to recognize person detected (fallback): {nearest_person.fullname} ({nearest_person.personCode})")
            # Use fixed threshold of 0.7 for hard to recognize persons
            hard_threshold = 0.35
            if nearest_person.scoreMatching >= hard_threshold:
                nearest_person.scoreMatching = min(
                    nearest_person.scoreMatching * 2, 1)
                print(
                    f"Found hard to recognize person (fallback): {nearest_person.fullname} with score {nearest_person.scoreMatching:.3f}")
                return [nearest_person], nearest_person
            else:
                print(
                    f"Hard to recognize person {nearest_person.fullname} below threshold {hard_threshold}")
                return [], None

        # Normal person processing
        if nearest_person.scoreMatching >= threshold:
            nearest_person.scoreMatching = min(
                nearest_person.scoreMatching * 2, 1)
            return [nearest_person], nearest_person

        return [], None

    def search_event(
        self,
        face_embedding: np.ndarray,
        com_ids: Optional[List[int]],
        threshold: float,
        num_result: int = 1,
        from_date: Optional[datetime] = None,
        to_date: Optional[datetime] = None,
        wear_mask: int = 0,
    ) -> List[EventResult]:
        """Search event records in PostgreSQL by face embedding."""
        if not self.validate_embedding(face_embedding):
            return []

        if num_result <= 0:
            return []

        threshold = max(0.0, threshold - 0.1 * int(bool(wear_mask)))

        event_table = self._qualified_table(app_config.EVENT_TABLE_NAME)
        event_id_col = app_config.EVENT_ID_COLUMN
        feature_col = app_config.EVENT_FEATURE_COLUMN  # View_ListEvent: FacePath chính là feature
        comp_col = app_config.EVENT_COMPID_COLUMN
        time_col = app_config.EVENT_TIME_COLUMN

        conn = None
        cursor = None
        try:
            conn = psycopg2.connect(**self.conn_params)
            cursor = conn.cursor()

            query = (
                f'SELECT "{event_id_col}", "{feature_col}" '
                f'FROM {event_table} '
                f'WHERE "{feature_col}" IS NOT NULL AND "{feature_col}" != \'\''
            )
            params = []

            if com_ids:
                comp_placeholders = ",".join(["%s"] * len(com_ids))
                query += f' AND "{comp_col}" IN ({comp_placeholders})'
                params.extend(com_ids)

            if from_date is not None:
                query += f' AND "{time_col}" >= %s'
                params.append(from_date.strftime("%Y-%m-%d %H:%M:%S"))
            if to_date is not None:
                query += f' AND "{time_col}" <= %s'
                params.append(to_date.strftime("%Y-%m-%d %H:%M:%S"))

            cursor.execute(query, tuple(params))
            rows = cursor.fetchall()

            results: List[EventResult] = []
            for row in rows:
                event_id, face_feature = row
                if not face_feature:
                    continue
                try:
                    decoded_feature = decode_embedding(face_feature, app_config.SECRET_KEY)
                    score = min(2 * cosine_similarity(face_embedding, decoded_feature), 1)
                except Exception as e:
                    print(f"Error decoding event feature: {e}")
                    continue

                if score >= threshold:
                    results.append(
                        EventResult(
                            eventId=str(event_id),
                            score=float(score),
                        )
                    )

            results.sort(key=lambda x: x.score, reverse=True)
            return results[:num_result]
        except Exception as e:
            print(f"Error searching events: {e}")
            return []
        finally:
            if cursor is not None:
                cursor.close()
            if conn is not None:
                conn.close()

    def clear_cache(self):
        """Clear the face features matrix to free memory."""
        self.face_features_matrix = None
        self.person_indices = []
        print("Cleared face features cache")

    def get_embedding_dimension(self) -> int:
        """Get the dimension of face embeddings."""
        if self.face_features_matrix is not None:
            return self.face_features_matrix.shape[1]
        return 0

    def validate_embedding(self, embedding: np.ndarray) -> bool:
        """Validate if embedding has correct dimension (512)."""
        if embedding is None:
            return False

        actual_dim = embedding.shape[0] if embedding.ndim == 1 else embedding.size
        expected_dim = 512

        if actual_dim != expected_dim:
            print(
                f"Warning: Embedding dimension mismatch. Expected: {expected_dim}, Got: {actual_dim}")
            return False
        return True


# Create a singleton instance
database_manager = DatabaseManager()
