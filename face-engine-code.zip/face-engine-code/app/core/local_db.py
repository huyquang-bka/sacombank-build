import asyncio
import sqlite3
from datetime import datetime
from typing import Any, Dict, List, Tuple

import psycopg2

from app.core.config import app_config


class LocalDatabaseManager:
    def __init__(self):
        self.db_path = "local_persons.db"
        self.conn_params = {
            "host": app_config.DATABASE_URL,
            "port": app_config.DATABASE_PORT,
            "dbname": app_config.DATABASE_NAME,
            "user": app_config.DATABASE_USERNAME,
            "password": app_config.DATABASE_PASSWORD,
            "options": f"-c search_path={app_config.DATABASE_SCHEMA}",
        }
        self._lock = asyncio.Lock()
        self._init_db()

    @staticmethod
    def _quote_identifier(identifier: str) -> str:
        return '"' + identifier.replace('"', '""') + '"'

    def _qualified_table(self, table_name: str) -> str:
        return (
            f"{self._quote_identifier(app_config.DATABASE_SCHEMA)}."
            f"{self._quote_identifier(table_name)}"
        )

    def _init_db(self):
        """Initialize SQLite database with required tables"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        # Create persons table
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS persons (
            personId TEXT PRIMARY KEY,
            compId INTEGER,
            personCode TEXT,
            fullname TEXT,
            deptName TEXT,
            position TEXT,
            jobDuties TEXT,
            passport TEXT,
            phoneNumber TEXT,
            personType INTEGER,
            avatarPath TEXT,
            faceFeature TEXT,
            faceStatus INTEGER,
            status INTEGER,
            is_deleted INTEGER DEFAULT 0,
            last_sync TIMESTAMP
        )
        """)

        conn.commit()
        conn.close()

    @staticmethod
    def _normalize_face_feature(face_feature: Any) -> str:
        if face_feature is None:
            return ""
        if isinstance(face_feature, (bytes, bytearray)):
            return face_feature.decode("utf-8", errors="replace")
        return str(face_feature)

    @staticmethod
    def _to_int(value: Any, default: int = 0) -> int:
        try:
            if isinstance(value, bool):
                return int(value)
            if value is None:
                return default
            return int(value)
        except (TypeError, ValueError):
            return default

    def _build_sqlite_value(
        self, person: Dict[str, Any], current_time: str
    ) -> Tuple[Any, ...]:
        person_id = person.get("personId", person.get("PersonId", person.get("Id")))
        if person_id is not None:
            person_id = str(person_id)

        face_feature = self._normalize_face_feature(
            person.get("faceFeature", person.get("FaceFeature"))
        )

        dept_val = person.get("deptName", person.get("DeptName"))
        if dept_val is None and person.get("DeptId") is not None:
            dept_val = str(person["DeptId"])

        return (
            person_id,
            person.get("compId", person.get("CompId")),
            person.get("personCode", person.get("PersonCode", person.get("Code"))),
            person.get("fullname", person.get("Fullname")),
            dept_val,
            person.get("position", person.get("Position")),
            person.get("jobDuties", person.get("JobDuties")),
            person.get("passport", person.get("Passport")),
            person.get("phoneNumber", person.get("PhoneNumber")),
            person.get("personType", person.get("PersonType")),
            person.get("avatarPath", person.get("AvatarPath")),
            face_feature,
            person.get("faceStatus", person.get("FaceStatus")),
            person.get("status", person.get("Status")),
            self._to_int(person.get("is_deleted", person.get("IsDelete")), 0),
            current_time,
        )

    def _replace_persons_sync(self, persons: List[Dict[str, Any]]):
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        current_time = datetime.utcnow().isoformat()

        values: List[Tuple[Any, ...]] = []
        for person in persons:
            sqlite_value = self._build_sqlite_value(person, current_time)
            if not sqlite_value[0]:
                continue
            values.append(sqlite_value)

        try:
            cursor.execute("BEGIN IMMEDIATE")
            cursor.execute("DELETE FROM persons")
            if values:
                cursor.executemany(
                    """
                    INSERT OR REPLACE INTO persons
                    (personId, compId, personCode, fullname, deptName, position, jobDuties,
                    passport, phoneNumber, personType, avatarPath, faceFeature, faceStatus,
                    status, is_deleted, last_sync)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    values,
                )
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    async def save_persons(self, persons: List[Dict[str, Any]]):
        """Save persons into local SQLite in one transaction."""
        async with self._lock:
            loop = asyncio.get_running_loop()
            await loop.run_in_executor(None, self._replace_persons_sync, persons)

    def _fetch_persons_from_pg_sync(self) -> List[Dict[str, Any]]:
        conn = None
        cursor = None
        try:
            conn = psycopg2.connect(**self.conn_params)
            cursor = conn.cursor()
            person_t = app_config.PERSON_TABLE_NAME
            face_t = app_config.FACE_TABLE_NAME
            person_table = self._qualified_table(person_t)
            face_table = self._qualified_table(face_t)
            query = f"""
                SELECT DISTINCT p."PersonId", p."CompId", p."DeptId", p."PersonCode", p."Fullname",
                    p."Position", p."JobDuties", p."Passport", p."PhoneNumber", p."PersonType",
                    p."AvatarPath", p."Status", p."IsDelete", f."FeaturePath"
                FROM {person_table} p
                INNER JOIN {face_table} f ON f."PersonId" = p."PersonId"
                WHERE p."IsDelete" = false 
                  AND p."Status" != 0 
                  AND p."Status" IS NOT NULL
                  AND f."FeaturePath" IS NOT NULL AND f."FeaturePath" != ''
                  AND (f."Status" IS NULL OR f."Status" != 0)
            """
            cursor.execute(query)
            rows = cursor.fetchall()

            persons: List[Dict[str, Any]] = []
            for row in rows:
                (
                    person_id,
                    comp_id,
                    dept_id,
                    person_code,
                    fullname,
                    position,
                    job_duties,
                    passport,
                    phone_number,
                    person_type,
                    avatar_path,
                    status,
                    is_delete,
                    feature_path,
                ) = row
                if person_id is None:
                    continue
                feature_value = self._normalize_face_feature(feature_path)
                persons.append(
                    {
                        "PersonId": person_id,
                        "CompId": comp_id,
                        "DeptId": dept_id,
                        "PersonCode": person_code,
                        "Fullname": fullname,
                        "Position": position,
                        "JobDuties": job_duties,
                        "Passport": passport,
                        "PhoneNumber": phone_number,
                        "PersonType": person_type,
                        "AvatarPath": avatar_path,
                        "Status": status,
                        "IsDelete": is_delete,
                        "FaceFeature": feature_path,
                        "faceFeature": feature_value,
                        "is_deleted": self._to_int(is_delete, 0),
                    }
                )
            return persons
        finally:
            if cursor is not None:
                cursor.close()
            if conn is not None:
                conn.close()

    async def get_all_persons(self) -> List[Dict[str, Any]]:
        """Retrieve all persons from local database"""
        async with self._lock:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()

            cursor.execute("SELECT * FROM persons WHERE is_deleted = 0")
            columns = [description[0] for description in cursor.description]
            persons = []

            for row in cursor.fetchall():
                person = dict(zip(columns, row))
                persons.append(person)

            conn.close()
            return persons

    async def sync_persons(self):
        """Sync persons from PostgreSQL and replace local SQLite atomically."""
        try:
            loop = asyncio.get_running_loop()
            persons = await loop.run_in_executor(None, self._fetch_persons_from_pg_sync)
            async with self._lock:
                await loop.run_in_executor(None, self._replace_persons_sync, persons)

            print(f"Synced {len(persons)} persons from PostgreSQL to local SQLite")

            from app.core.database_manager import database_manager

            await database_manager.load_persons()
        except Exception as e:
            print(f"Error during sync from PostgreSQL: {str(e)}")


# Create a singleton instance
local_db_manager = LocalDatabaseManager()
