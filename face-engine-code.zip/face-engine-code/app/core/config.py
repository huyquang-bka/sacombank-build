import yaml
import json
from typing import List, Optional
from pydantic import BaseModel
from pydantic_settings import BaseSettings
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv("resources/.env")


class ModelConfig(BaseModel):
    weight: str
    device: str = "0"
    mean: List[float] = [0.485, 0.456, 0.406]
    std: List[float] = [0.229, 0.224, 0.225]


class RecognizeConfig(BaseModel):
    context_id: int = 0
    device_id: int = 0
    det_size: List[int] = [320, 320]


class AppConfig(BaseSettings):
    # APP
    APP_NAME: str
    APP_VERSION: str
    API_V1_STR: str
    ALLOWED_ORIGINS: List[str] = ["*"]

    # API
    API_HOST: str
    API_PORT: int
    API_WORKERS: int
    API_RELOAD: bool
    SECRET_KEY: str

    # THRESHOLD
    SIMILARITY_THRESHOLD: float

    # Database
    DATABASE_URL: str
    DATABASE_PORT: int
    DATABASE_USERNAME: str
    DATABASE_PASSWORD: str
    DATABASE_NAME: str
    DATABASE_SCHEMA: str = "camerastb"
    PERSON_TABLE_NAME: str
    PAGE_SIZE: int
    FACE_TABLE_NAME: str
    EVENT_TABLE_NAME: str
    EVENT_ID_COLUMN: str = "EventId"
    EVENT_FEATURE_COLUMN: str = "FeaturePath"  # View_ListEvent dùng FacePath (chính là feature)
    EVENT_COMPID_COLUMN: str = "CompId"
    EVENT_TIME_COLUMN: str = "AccessTime"

    # Sync configuration
    TIME_PER_SYNC: int = 5  # minutes

    # Database reload configuration
    RELOAD_DB: bool = True

    # Configs
    recognize: RecognizeConfig
    face_quality: ModelConfig
    face_mask: ModelConfig


class Config:
    env_file = "resources/.env"
    env_file_encoding = "utf-8"


def load_yaml_config(file_path: str) -> dict:
    """Helper function to load YAML config."""
    with open(file_path, "r") as file:
        return yaml.safe_load(file)


def load_config() -> AppConfig:
    # Load configurations from YAML files
    recognize_config = load_yaml_config("resources/config/recognize.yaml")
    model_config = load_yaml_config("resources/config/models.yaml")
    return AppConfig(**recognize_config, **model_config)


# Create an instance of the config
app_config = load_config()

if __name__ == "__main__":
    print(json.dumps(app_config.model_dump(), indent=4))
