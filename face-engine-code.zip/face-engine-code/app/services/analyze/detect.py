import numpy as np
import cv2
import torch
from app.schemas.analyze.detect import FaceDetectRequest, FaceDetectResponse
from app.utils.helpers import base64_to_image
from app.core.model_manager import (
    insightface_model_manager,
    face_quality_model_manager,
    face_mask_model_manager,
)
from app.utils.helpers import encode_embedding
from datetime import datetime
from app.utils.helpers import expand_image


async def detect_face(request: FaceDetectRequest) -> FaceDetectResponse:
    """
    Detect face, calculate quality score, check for mask, and extract embedding.

    Args:
        request (FaceDetectRequest): Request containing base64 image

    Returns:
        FaceDetectResponse: Response containing face detection results
    """
    try:
        start_time = datetime.now()

        # Get and validate image
        image = await _get_valid_image(request)
        if isinstance(image, FaceDetectResponse):
            return image

        # Detect faces
        faces = await _detect_faces(image)
        if isinstance(faces, FaceDetectResponse):
            return faces

        # Process largest face
        largest_face = max(
            faces, key=lambda x: (x.bbox[2] - x.bbox[0]) * (x.bbox[3] - x.bbox[1])
        )

        # Get face rectangle and crop
        face_rectangle = [int(x) for x in largest_face.bbox]
        expanded_face_rectangle = expand_image(face_rectangle, image)
        face_crop = image[
            face_rectangle[1] : face_rectangle[3], face_rectangle[0] : face_rectangle[2]
        ]

        # Convert to RGB for model processing
        face_crop_rgb = cv2.cvtColor(face_crop, cv2.COLOR_BGR2RGB)

        # Get embedding vector
        embedding_vector = largest_face.embedding

        # Process face quality and mask detection
        quality_score = await _get_face_quality(face_crop_rgb)
        wear_mask = await _detect_mask(face_crop_rgb)

        process_time = (datetime.now() - start_time).total_seconds()

        return FaceDetectResponse(
            timestamp=datetime.now().isoformat(),
            status=200,
            error="Success",
            data={
                "thumbnail": request.img_base64,
                "feature": encode_embedding(embedding_vector),
                "face_rectangle": expanded_face_rectangle,
                "quality": quality_score,
                "wearmask": 1 if wear_mask else 0,
                "decode_time": 0,
                "process_time": process_time,
            },
        )

    except Exception as e:
        return FaceDetectResponse(
            timestamp=datetime.now().isoformat(), status=500, error=str(e), data=None
        )


async def _get_valid_image(request: FaceDetectRequest):
    """Get and validate image from request."""
    if request.img_base64:
        image = await base64_to_image(request.img_base64)
    else:
        return FaceDetectResponse(
            timestamp=datetime.now().isoformat(),
            status=400,
            error="Need img_base64",
            data=None,
        )

    if image is None:
        return FaceDetectResponse(
            timestamp=datetime.now().isoformat(),
            status=400,
            error="Invalid image format",
            data=None,
        )

    return image


async def _detect_faces(image):
    """Detect faces in image using InsightFace asynchronously."""
    model = await insightface_model_manager.get_model()
    faces = model.detect(image)

    if not faces:
        return FaceDetectResponse(
            timestamp=datetime.now().isoformat(),
            status=400,
            error="No face detected",
            data=None,
        )

    return faces


async def _get_face_quality(face_crop: np.ndarray) -> float:
    """Calculate face quality score asynchronously."""
    quality_model = await face_quality_model_manager.get_model()

    with torch.no_grad():
        quality_score = float(quality_model.detect(face_crop))
    return quality_score


async def _detect_mask(face_crop: np.ndarray) -> int:
    """Detect if face is wearing a mask."""
    mask_model = await face_mask_model_manager.get_model()

    with torch.no_grad():
        wear_mask = mask_model.detect(face_crop)
    return wear_mask
