# Plan: Migrate MSSQL -> PostgreSQL (face-engine)

## Target PostgreSQL

- Host: **192.168.1.19**
- Port: **5432**
- User: **postgres**
- Pass: **Ab@123456**
- DB: **Sacombank**
- Tables:
  - Persons
  - Faces
  - Events

## 1) Inventory & Assumptions

- Locate all MSSQL usage (drivers, connection strings, queries).
- Current code likely pulls person data from DB/API in `app/core/local_db.py` or related.
- Confirm current schema/tables used (e.g., Persons/Person/Feature tables).

## 2) Schema Mapping

- Map MSSQL → PostgreSQL types:
  - `uniqueidentifier` → `uuid`
  - `nvarchar/varchar` → `varchar/text`
  - `bit` → `boolean`
  - `datetime` → `timestamp`
  - `varbinary/image` → `bytea`
- Confirm indices & primary keys.
- If feature vectors stored: ensure bytea encoding/decoding logic in app.

## 3) Update Config / Env ✅

- Replace MSSQL settings with PostgreSQL env:
  - `DATABASE_URL=192.168.1.19`, `DATABASE_PORT=5432`, `DATABASE_USERNAME`, `DATABASE_PASSWORD`, `DATABASE_NAME=Sacombank`
- Env dùng trong `env.example` và `resources/.env` (không còn MSSQL connection string).

## 4) Driver & Code Changes ✅

- Đã thay driver: `pymssql` → `psycopg2-binary` (trong `requirements.txt`).
- Kết nối: `psycopg2.connect(host=..., port=..., dbname=..., user=..., password=...)` trong `database_manager.py` và `local_db.py`.
- SQL: dùng identifier dạng `"TableName"`, `"ColumnName"` (PostgreSQL); `IsDelete = false`; placeholders vẫn `%s`.

## 5) Data Migration

- Export MSSQL data to CSV/SQL.
- Import into PostgreSQL using `COPY` or `psql`.
- Validate row counts and checksum of feature blobs.

## 6) Testing

- Unit test DB queries for persons/embeddings.
- End-to-end: sync persons, run `/searchFace`, check latency.
- Verify no NULL regressions in response.

## 7) Rollback Plan

- Keep MSSQL config as backup.
- Feature flag to switch DB provider (env var).
- Keep last exported MSSQL snapshot.
