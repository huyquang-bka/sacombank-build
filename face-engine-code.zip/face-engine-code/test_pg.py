import psycopg2

# Database configuration
DATABASE_URL = '192.168.1.19'
DATABASE_PORT = 5432
DATABASE_USERNAME = 'postgres'
DATABASE_PASSWORD = 'Ab@123456'
DATABASE_NAME = 'Sacombank'
PERSON_TABLE_NAME = 'Persons'
FACE_TABLE_NAME = "Faces"
EVENT_TABLE_NAME = "View_ListEvent"

def get_columns(conn, table_name):
    with conn.cursor() as cur:
        cur.execute(
            """
            SELECT column_name, data_type, is_nullable, column_default
            FROM information_schema.columns 
            WHERE table_schema = 'public' AND table_name = %s
            ORDER BY ordinal_position;
            """,
            (table_name,),
        )
        return cur.fetchall()

def print_table_fields(table_name, conn):
    columns = get_columns(conn, table_name)
    print(f"Fields of table '{table_name}':")
    for col in columns:
        col_name, data_type, nullable, default = col
        print(
            f"    {col_name} | {data_type} | nullable={nullable} | default={default}"
        )
    print()

def main():
    conn = psycopg2.connect(
        host=DATABASE_URL,
        port=DATABASE_PORT,
        user=DATABASE_USERNAME,
        password=DATABASE_PASSWORD,
        database=DATABASE_NAME,
    )

    tables = [PERSON_TABLE_NAME, FACE_TABLE_NAME, EVENT_TABLE_NAME]
    for table in tables:
        print_table_fields(table, conn)

    conn.close()

if __name__ == "__main__":
    main()
