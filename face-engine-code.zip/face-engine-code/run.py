import os

import uvicorn
from app.core.config import app_config
from app.main import app

# Prevent albumentations from trying to reach the public internet on startup.
os.environ.setdefault("NO_ALBUMENTATIONS_UPDATE", "1")

if __name__ == "__main__":
    uvicorn_kwargs = {
        "app": app,
        "host": app_config.API_HOST,
        "port": app_config.API_PORT,
    }
    if app_config.API_WORKERS > 1:
        uvicorn_kwargs["workers"] = app_config.API_WORKERS
    if app_config.API_RELOAD:
        uvicorn_kwargs["reload"] = app_config.API_RELOAD
    uvicorn.run(**uvicorn_kwargs)
