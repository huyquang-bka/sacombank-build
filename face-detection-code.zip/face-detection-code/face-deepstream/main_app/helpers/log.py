import sys

RESET = "\033[0m"

COLORS = {
    "capture": "\033[31m",   # red
    "tracking": "\033[32m",  # green
    "gather": "\033[33m",    # yellow
    "recognize": "\033[34m", # blue
    "event": "\033[35m",     # magenta
    "token": "\033[36m",     # cyan
}


def tlog(channel: str, *args):
    color = COLORS.get(channel, "")
    prefix = f"[{channel.upper()}]"
    message = " ".join(str(a) for a in args)
    if color:
        print(f"{color}{prefix} {message}{RESET}")
    else:
        print(f"{prefix} {message}")
    sys.stdout.flush()
