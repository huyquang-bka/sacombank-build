import time
from threading import Lock
from typing import Dict, Optional, Tuple


class RecognitionState:
    def __init__(self):
        self._lock = Lock()
        self._names: Dict[Tuple[int, int], str] = {}
        self._updated_at: Dict[Tuple[int, int], float] = {}

    def set_name(self, camera_id: int, tracked_id: int, person_name: str):
        with self._lock:
            key = (camera_id, tracked_id)
            self._names[key] = person_name
            self._updated_at[key] = time.time()

    def get_name(self, camera_id: int, tracked_id: int) -> Optional[str]:
        with self._lock:
            return self._names.get((camera_id, tracked_id))

    def remove_name(self, camera_id: int, tracked_id: int):
        with self._lock:
            key = (camera_id, tracked_id)
            self._names.pop(key, None)
            self._updated_at.pop(key, None)

    def prune_expired(self, max_age_seconds: float):
        now = time.time()
        with self._lock:
            expired_keys = [
                key for key, updated_at in self._updated_at.items()
                if now - updated_at >= max_age_seconds
            ]
            for key in expired_keys:
                self._names.pop(key, None)
                self._updated_at.pop(key, None)


recognition_state = RecognitionState()
