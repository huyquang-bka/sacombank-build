
import pyds
import numpy as np
import traceback

def get_surface_from_buffer(gst_buffer, batch_id):
    surface = pyds.get_nvds_buf_surface(hash(gst_buffer), batch_id)
    return surface

def get_frame_from_buffer(surface):
    try:
        frame_copy = np.array(surface, copy=True, order='C')
        if frame_copy.ndim == 3 and frame_copy.shape[2] == 4:
            return frame_copy
        else:
            print(f"Error: Final frame shape invalid: {frame_copy.shape}")
            return None
    except Exception as e:
        print(f"Error extracting frame: {e}")
        traceback.print_exc()
        return None