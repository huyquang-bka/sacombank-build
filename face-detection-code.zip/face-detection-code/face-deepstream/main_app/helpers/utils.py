import os
import cv2
import numpy as np
import string
from datetime import datetime
import base64

classes = string.digits + string.ascii_uppercase

def is_bbox_inside_polygon(bbox: list, polygon: list):
    """
    Check if the center of the bounding box is inside the polygon.
    bbox: [x1, y1, x2, y2, ...]
    polygon: list of [x, y] points, e.g. [[x1, y1], [x2, y2], ...]
    """
    if not polygon or len(polygon) < 3:
        return False
    
    x1, y1, x2, y2 = bbox[:4]
    cx = (x1 + x2) // 2
    cy = (y1 + y2) // 2
    
    # Ensure pts is a numpy array of type float32, properly shaped and contiguous for cv2.pointPolygonTest
    # OpenCV expects shape (N, 1, 2) or (N, 2) where N is the number of points
    try:
        pts = np.array(polygon, dtype=np.float32)
        if pts.size == 0 or len(pts.shape) != 2 or pts.shape[1] != 2:
            return False
        
        # Ensure the array is contiguous (required by OpenCV)
        if not pts.flags['C_CONTIGUOUS']:
            pts = np.ascontiguousarray(pts)
        
        # Reshape to (N, 1, 2) format which is more reliable for OpenCV
        pts = pts.reshape(-1, 1, 2)
        
        return cv2.pointPolygonTest(pts, (float(cx), float(cy)), False) >= 0
    except (ValueError, TypeError):
        return False

def get_id_tracked_dict_inside_polygon(tracked_dict: dict, polygon: list):
    """
    Return a new dict with only objects whose bbox center is inside the polygon.
    """
    if not polygon:
        return tracked_dict
    new_tracked_dict = {}
    for object_id, bbox in tracked_dict.items():
        if is_bbox_inside_polygon(bbox, polygon):
            new_tracked_dict[object_id] = bbox
    return new_tracked_dict

def is_square_lp(digit_list: list) -> bool:
    if not digit_list:
        return False
    x_coords = [coord for digit in digit_list for coord in (
        digit[0], digit[2])]
    length_digit = sum(digit[2] - digit[0] for digit in digit_list)
    length_plate = max(x_coords) - min(x_coords)
    return length_plate / length_digit <= 2

def process_square_lp(bboxes: list) -> list:
        if not bboxes:
            return []
        average_y = sum(box[1] for box in bboxes) / len(bboxes)
        upper_line = sorted([box for box in bboxes if box[1]
                            < average_y], key=lambda x: x[0])
        lower_line = sorted([box for box in bboxes if box[1]
                            >= average_y], key=lambda x: x[0])
        return upper_line + lower_line

def get_plate_number(digit_info: list):
    """
    Get the plate number from the digit info.
    digit_info: list of digit bboxes, each bbox is [x1, y1, x2, y2, confidence, class_id]
    """
    if not digit_info:
        return ""
    if is_square_lp(digit_info):
        digit_info = process_square_lp(digit_info)
    plate_number = ""
    for digit_bbox in digit_info:
        if len(digit_bbox) > 5:
            digit_class = int(digit_bbox[5])
            if 0 <= digit_class < len(classes):
                plate_number += classes[digit_class]
    return plate_number


def is_bbox_inside_bbox(inner_bbox: list, outer_bbox: list) -> bool:
    """
    Check if inner_bbox is inside outer_bbox using spatial containment.
    Args:
        inner_bbox: [x1, y1, x2, y2, ...]
        outer_bbox: [x1, y1, x2, y2, ...]
    Returns:
        True if inner_bbox is completely inside outer_bbox
    """
    inner_x1, inner_y1, inner_x2, inner_y2 = inner_bbox[:4]
    inner_cx = (inner_x1 + inner_x2) // 2
    inner_cy = (inner_y1 + inner_y2) // 2
    outer_x1, outer_y1, outer_x2, outer_y2 = outer_bbox[:4]
    return (outer_x1 <= inner_cx and inner_cx <= outer_x2 and 
            outer_y1 <= inner_cy and inner_cy <= outer_y2)

def match_digits_to_plates(plates: list, digits: list) -> dict:
    """
    Match digits to plates based on spatial containment.
    Args:
        plates: list of plate bboxes, each is [x1, y1, x2, y2, confidence, class_id]
        digits: list of digit bboxes, each is [x1, y1, x2, y2, confidence, class_id]
    Returns:
        {plate_index: [list of matched digit bboxes sorted by x-coordinate]}
    """
    plate_digits_map = {}
    
    for plate_idx, plate_bbox in enumerate(plates):
        matched_digits = []
        
        for digit_bbox in digits:
            if is_bbox_inside_bbox(digit_bbox, plate_bbox):
                matched_digits.append(digit_bbox)
        
        if matched_digits:
            # Sort digits by x-coordinate (left to right) for proper reading order
            matched_digits.sort(key=lambda x: x[0])
            plate_digits_map[plate_idx] = matched_digits
    
    return plate_digits_map

def match_plates_to_vehicles(vehicles: dict, plates: list, plate_digits_map: dict) -> dict:
    """
    Match plates to vehicles based on spatial containment.
    Args:
        vehicles: {vehicle_id: vehicle_bbox} where bbox is [x1, y1, x2, y2, confidence, class_id]
        plates: list of plate bboxes, each is [x1, y1, x2, y2, confidence, class_id]
        plate_digits_map: {plate_index: [list of matched digit bboxes]} from match_digits_to_plates
    Returns:
        {vehicle_id: (vehicle_bbox, best_plate_bbox, matched_digits)}
    """
    vehicle_plates_map = {}
    
    for vehicle_id, vehicle_bbox in vehicles.items():
        matched_plates = []
        
        # Find all plates inside this vehicle
        for plate_idx, plate_bbox in enumerate(plates):
            if is_bbox_inside_bbox(plate_bbox, vehicle_bbox):
                # Get digits for this plate if available
                plate_digits = plate_digits_map.get(plate_idx, [])
                matched_plates.append({
                    'bbox': plate_bbox,
                    'digits': plate_digits,
                    'confidence': plate_bbox[4] if len(plate_bbox) > 4 else 0.0
                })
        
        if matched_plates:
            # Sort by confidence and take the best plate
            matched_plates.sort(key=lambda x: x['confidence'], reverse=True)
            best_plate = matched_plates[0]
            vehicle_plates_map[vehicle_id] = (
                vehicle_bbox,
                best_plate['bbox'],
                best_plate['digits']
            )
    
    return vehicle_plates_map

def build_tracked_dict(vehicles: dict, plates: list, digits: list, polygon: list = None) -> dict:
    """
    Build tracked_dict by mapping digits -> plates -> vehicles -> polygon filter.
    This is the main function to process raw detection data.
    Args:
        vehicles: {vehicle_id: vehicle_bbox} where bbox is [x1, y1, x2, y2, confidence, class_id]
        plates: list of plate bboxes, each is [x1, y1, x2, y2, confidence, class_id]
        digits: list of digit bboxes, each is [x1, y1, x2, y2, confidence, class_id]
        polygon: optional polygon for filtering vehicles, list of [x, y] points
    Returns:
        {vehicle_id: [x1, y1, x2, y2, confidence, class_id, plate_bbox, digit_list]}
        Only vehicles with plates and inside polygon (if provided) are included.
    """
    tracked_dict = {}
    
    # Step 1: Match digits to plates
    plate_digits_map = match_digits_to_plates(plates, digits)
    
    # Step 2: Match plates to vehicles
    vehicle_plates_map = match_plates_to_vehicles(vehicles, plates, plate_digits_map)
    
    # Step 3: Filter vehicles in polygon and build final tracked_dict
    for vehicle_id, (vehicle_bbox, plate_bbox, digit_list) in vehicle_plates_map.items():
        # Filter by polygon: only keep vehicles inside polygon
        if polygon is None or is_bbox_inside_polygon(vehicle_bbox, polygon):
            # Format: [x1, y1, x2, y2, confidence, class_id, plate_info, digit_info, text]
            text = get_plate_number(digit_list)
            bbox_extended = vehicle_bbox + [plate_bbox, digit_list, text]
            tracked_dict[vehicle_id] = bbox_extended
    
    return tracked_dict

def get_most_frequent_text(text_list: list) -> str:
    """
    Get the most frequent text from the list.
    text_list: list of text
    """
    new_text_list = [text for text in text_list if text]
    if not new_text_list:
        return ""
    return max(set(new_text_list), key=new_text_list.count) if new_text_list else ""

def expand_box(bbox, ratio: float = 0.1):
    """
    Expand the bounding box by a given ratio.
    Args:
        bbox: [x1, y1, x2, y2, ...] list or tuple; only the first four coords are used.
        ratio: float, expand by this percent of box size (default 0.1 = 10%)
    Returns:
        list: expanded bbox [x1, y1, x2, y2, ...] (other elements remain unchanged)
    """
    if not bbox or len(bbox) < 4:
        return bbox

    x1, y1, x2, y2 = bbox[:4]
    w = x2 - x1
    h = y2 - y1
    x1_new = int(round(x1 - w * ratio))
    y1_new = int(round(y1 - h * ratio))
    x2_new = int(round(x2 + w * ratio))
    y2_new = int(round(y2 + h * ratio))
    # Compose new bbox (expand only the first 4 values)
    expanded_bbox = [x1_new, y1_new, x2_new, y2_new]
    # Append any extra elements in original bbox
    if len(bbox) > 4:
        expanded_bbox += list(bbox[4:])
    return expanded_bbox

def expand_dict(tracked_dict: dict, ratio=0.2):
    """
    Apply expand_box to every bbox in tracked_dict.
    Args:
        tracked_dict: {object_id: bbox}, where bbox is list/tuple with at least 4 values
        ratio: float, expand by this percent of box size (default 0.1 = 10%)
    Returns:
        dict: {object_id: expanded_bbox}
    """
    if not isinstance(tracked_dict, dict):
        return tracked_dict
    expanded = {}
    for k, v in tracked_dict.items():
        expanded[k] = expand_box(v, ratio)
    return expanded


def image_to_base64(image):
    img_to_byte = cv2.imencode('.jpg', image)[1].tobytes()
    byte_to_base64 = base64.b64encode(img_to_byte)
    return byte_to_base64.decode('ascii')  # chuyển về string
