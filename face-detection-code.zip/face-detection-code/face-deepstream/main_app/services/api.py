import json
import time
import os
import requests
from ..models import faceConfig, accessToken
import aiohttp


class APIFace:
    def __init__(self):
        self.headers = faceConfig.HEADER_RECOGNIZE_FACE_ARC

    async def recognize_face(self, payload):
        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    url=faceConfig.URL_RECOGNIZE_FACE_ARC,
                    headers=self.headers,
                    json=payload,
                    timeout=10,
                ) as response:
                    return await response.json()
        except Exception as e:
            print(f"Error api_recognize_face_async: {e}")
            return {}

apiFace = APIFace()


def log_failed_request(payload, error_message: str = None, response_data=None):
    """Log failed request to failed-requests folder"""
    try:
        failed_requests_dir = "failed-requests"
        if not os.path.exists(failed_requests_dir):
            os.makedirs(failed_requests_dir)

        event_id = payload.get("eventId", f"unknown_{int(time.time())}")
        filename = f"{event_id}.json"
        filepath = os.path.join(failed_requests_dir, filename)

        log_payload = payload.copy()
        if "featurePath" in log_payload:
            del log_payload["featurePath"]
        if "ImageBase64" in log_payload:
            del log_payload["ImageBase64"]

        log_data = {
            "payload": log_payload,
            "error_message": error_message,
            "response_data": response_data,
            "timestamp": time.time(),
            "datetime": time.strftime("%Y-%m-%d %H:%M:%S")
        }

        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(log_data, f, indent=2, ensure_ascii=False)

        print(f"Failed request logged to: {filepath}")

    except Exception as e:
        print(f"Error logging failed request: {e}")


def api_get_token(URL, PAYLOAD, TIMEOUT=2):
    try:
        res = requests.post(URL, json=PAYLOAD,
                            timeout=TIMEOUT).json()
        access_token = res["access_token"]
        id_comp = res.get("comId")
        return (access_token, id_comp)
    except Exception as e:
        print(e)
        return (None, None)


def get_config_from_api(url_config):
    if accessToken.id_company is not None and "compId=" not in url_config:
        separator = "&" if "?" in url_config else "?"
        url_config = f"{url_config}{separator}compId={accessToken.id_company}"
    while True:
        try:
            header = {"Content-Type": "application/json",
                      "Authorization": "Bearer " + accessToken.value}
            response = requests.get(url_config, headers=header).json()[
                "data"]
            return response

        except Exception as e:
            print("Error get config from api: ", e)
            print('Retrying get config from api...')
            time.sleep(1)

if __name__ == "__main__":
    pass
