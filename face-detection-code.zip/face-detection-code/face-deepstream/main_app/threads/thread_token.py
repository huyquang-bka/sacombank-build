from PyQt5 import QtCore
from ..models import accessToken, mainConfig
from ..services.api import api_get_token
import time
from ..helpers.log import tlog


class ThreadToken(QtCore.QThread):

    def __init__(self, parent=None):
        super().__init__(parent)
        self.__is_running = False
        self.url_token = mainConfig.URL_TOKEN
        self.payload_token = mainConfig.PAYLOAD_TOKEN
        self.timeout = mainConfig.TIMEOUT
        self.time_token = mainConfig.TIME_TOKEN

    def run(self):
        self.__is_running = True
        old_time = 0
        while self.__is_running:
            time.sleep(1)
            if time.time() - old_time < self.time_token:
                self.sleep(1)
                continue

            token, id_comp = api_get_token(
                self.url_token, self.payload_token, self.timeout)

            if token is None:
                self.sleep(5)
                continue

            accessToken.value = token
            accessToken.id_company = id_comp
            old_time = time.time()
            tlog("token", "Get token success!")

    def stop(self):
        self.__is_running = False
