import asyncio
import aiohttp
from typing import Dict, List, Tuple
from PyQt5 import QtCore
from ..models import accessToken, mainConfig, Face
from collections import deque
from ..services.api import log_failed_request
from ..helpers.log import tlog


class ThreadEvent(QtCore.QThread):
    def __init__(self, parent=None):
        super().__init__(parent=parent)
        self.__thread_active = False
        self.faces: deque[Face] = deque(maxlen=100)
        self._timeout = aiohttp.ClientTimeout(total=mainConfig.TIMEOUT)
        self._event_state_by_track: Dict[Tuple[int, int], Tuple[str, str]] = {}

    def _track_key(self, face: Face) -> Tuple[int, int]:
        return (face.camera_id, face.tracked_id)

    def on_face_recognized(self, face: Face):
        key = self._track_key(face)
        last_event = self._event_state_by_track.get(key)
        if last_event is not None and last_event[0] == face.personId:
            return
        self._event_state_by_track[key] = (face.personId, "pending")
        self.faces.append(face)
        #tlog("event", "***Add face to event***:", face.personName)

    def _build_headers(self):
        return {
            "Content-Type": "application/json",
            "Authorization": "Bearer " + accessToken.value,
        }

    async def _post_event(self, payload: dict):
        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(
                    url=mainConfig.URL_FACE,
                    json=payload,
                    headers=self._build_headers(),
                    timeout=self._timeout,
                ) as response:
                    if response.status == 200:
                        await response.json()
                        return True, None
                    return False, f"HTTP {response.status}: {response}"
        except asyncio.TimeoutError:
            return False, f"Async request timeout after {mainConfig.TIMEOUT} seconds"
        except Exception as e:
            return False, f"Async request failed: {e}"

    async def async_post_face_event(self, face: Face):
        #tlog("event", "***Ready to post face event***:", face.personName)
        payload = face.payload
        track_key = self._track_key(face)
        ok, msg = await self._post_event(payload)
        if ok:
            self._event_state_by_track[track_key] = (face.personId, "sent")
            #tlog("event", "***Post face event success***:", face.personName)
            return True
        last_event = self._event_state_by_track.get(track_key)
        if last_event is not None and last_event[0] == face.personId:
            self._event_state_by_track.pop(track_key, None)
        #tlog("event", "***Post face event failed***:", face.personName)
        log_failed_request(payload, msg)
        #tlog("event", msg)
        return False

    def process_faces_async(self, faces: List[Face]):
        if not faces:
            return

        tasks = []
        for face in faces:
            tasks.append(self.async_post_face_event(face))

        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)

        try:
            results = loop.run_until_complete(
                asyncio.gather(*tasks, return_exceptions=True))
            for i, result in enumerate(results):
                if isinstance(result, Exception):
                    tlog("event", f"Face event posting error: {result}")
                else:
                    try:
                        self.faces.remove(faces[i])
                    except Exception as e:
                        tlog("event", f"Error removing face from list: {e}")
        finally:
            loop.close()

    def run(self):
        self.__thread_active = True
        while self.__thread_active:
            face_list = list(self.faces)
            if face_list:
                self.process_faces_async(face_list)
            self.msleep(10)

    def stop(self):
        self.__thread_active = False
