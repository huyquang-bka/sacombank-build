from PyQt5 import QtCore
from queue import Queue
from ..models import Face, faceConfig
import time
from typing import Dict
from ..helpers.log import tlog
from ..helpers.recognition_state import recognition_state

class ThreadGather(QtCore.QThread):
    def __init__(self, consumer_queue: Queue, gather_queue: Queue):
        super().__init__()
        self.is_active = False
        self.consumer_queue = consumer_queue
        self.gather_queue = gather_queue

        # dict
        self.face_dict: Dict[int, Face] = {}

    def run(self):
        self.is_active = True
        tlog("gather", "Start thread gather")
        while self.is_active:
            recognition_state.prune_expired(faceConfig.RECOGNIZE_STATE_TIME)
            faces = []
            face_dict_copy = self.face_dict.copy()
            for tracked_id, face in face_dict_copy.items():
                if time.time() - face.init_time < faceConfig.TIME_LIMIT_PER_ID:
                    continue
                faces.append(face)
                #tlog("gather", "***Finish tracking face***:", tracked_id)
                del self.face_dict[tracked_id]
            if self.gather_queue.qsize() < 10:
                self.gather_queue.put(faces)
            if self.consumer_queue.empty():
                self.msleep(1)
                continue
            surface, raw_tracked_dict, camera_id = self.consumer_queue.get()
            for track_id, bbox in raw_tracked_dict.items():
                x1, y1, x2, y2, confidence, class_id = bbox[:6]
                if class_id != 0:
                    continue
                if track_id not in self.face_dict:
                    # first time
                    #tlog("gather", "***Init tracking face***:", track_id)
                    face = Face()
                    face.confidence = confidence
                    face.tracked_id = track_id
                    face.bbox = [x1, y1, x2, y2]
                    face.camera_id = camera_id
                    self.face_dict[track_id] = face
                else:
                    if self.face_dict[track_id].confidence < bbox[4]:
                        self.face_dict[track_id].confidence = bbox[4]
                        self.face_dict[track_id].bbox = [x1, y1, x2, y2]
                        self.face_dict[track_id].surface = surface

    def stop(self):
        self.is_active = False
