import time
from PyQt5 import QtCore
from queue import Queue
from ..models import CameraConfig
from ..helpers.ds import get_frame_from_buffer
from ..helpers.utils import expand_dict
import cv2
import numpy as np
from ..helpers.log import tlog

class ThreadConsumer(QtCore.QThread):
    def __init__(
        self,
        parent=None,
        camera_config: CameraConfig = None,
        tracking_queue: Queue = None,
        consumer_queue: Queue = None,
    ):
        super().__init__(parent)
        self.tracking_queue = tracking_queue
        self.consumer_queue = consumer_queue
        self.is_active = False
        self.camera_config = camera_config
        self.polygon = self.convert_polygon(camera_config.polygon) if camera_config else None

    def convert_polygon(self, polygon: list):
        if polygon is None:
            return None
        polygon = np.array(polygon, dtype=np.int32)
        polygon = polygon.reshape((-1, 1, 2))
        return polygon

    def run(self):
        self.is_active = True
        old_time = time.time()
        fps = 0
        
        while self.is_active:
            if time.time() - old_time >= 10:
                tlog("tracking", f"FPS of {self.camera_config.id}: {fps // 10}")
                fps = 0
                old_time = time.time()
            if self.tracking_queue.empty():
                self.msleep(1)
                continue
            fps += 1
            item = self.tracking_queue.get()
            surface, raw_tracked_dict = item
            if surface is None or raw_tracked_dict is None:
                self.msleep(1)
                continue
            if self.consumer_queue.empty():
                self.consumer_queue.put([surface, raw_tracked_dict, self.camera_config.id])
            self.msleep(1)

    def stop(self):
        self.is_active = False
