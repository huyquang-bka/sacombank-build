import asyncio
import time
from PyQt5.QtCore import QThread, pyqtSignal
from ..services.api import apiFace
from ..models import faceConfig, Face, CameraConfig
from collections import deque
from ..helpers.utils import image_to_base64
from queue import Queue
from typing import Dict, List, Optional, Tuple
from ..helpers.log import tlog
from ..helpers.recognition_state import recognition_state

class AsyncThreadRecognize(QThread):
    sig_recognized = pyqtSignal(dict)
    sig_face_recognized = pyqtSignal(Face)
    
    def __init__(self, parent=None, gather_queue: Optional[Queue] = None, camera_config: Optional[CameraConfig] = None):
        super().__init__(parent=parent)
        self.__thread_active = False

        self.gather_queue = gather_queue
        self.camera_config = camera_config
        self.recognized_cooldowns: Dict[Tuple[int, int], float] = {}
        self.old_unknown_id_list = deque(maxlen=100)

        self.recognized_dict = {}

    def _cooldown_key(self, camera_id: int, tracked_id: int) -> Tuple[int, int]:
        return (camera_id, tracked_id)

    def _prune_recognized_cooldowns(self):
        now = time.time()
        expired_keys = [
            key for key, expires_at in self.recognized_cooldowns.items()
            if now >= expires_at
        ]
        for key in expired_keys:
            self.recognized_cooldowns.pop(key, None)

    def _is_in_recognized_cooldown(self, camera_id: int, tracked_id: int) -> bool:
        self._prune_recognized_cooldowns()
        expires_at = self.recognized_cooldowns.get(self._cooldown_key(camera_id, tracked_id))
        return expires_at is not None and time.time() < expires_at

    async def async_recognize_face(self, face: Face):
        """Async version of face recognition"""
        payload = faceConfig.PAYLOAD_RECOGNIZE_FACE_ARC.copy()
        payload["img_base64"] = face.base64_image
        try:
            start_time = time.time()
            res = await apiFace.recognize_face(
                payload
            )
            #tlog("recognize", f"Async recognize time: {time.time() - start_time:.2f}s")

        except Exception as e:
            #tlog("recognize", f"Async request failed: {e}")
            return None

        # Process result
        if "Face not found".lower() in str(res.get("data", "Face not found")).lower():
            return None
        elif res.get("status", 500) != 200:
            return None
        else:
            face.handle_response(res)

        if face.personName != "Unknown":
            self.recognized_cooldowns[
                self._cooldown_key(face.camera_id, face.tracked_id)
            ] = time.time() + faceConfig.RECOGNIZE_STATE_TIME
            recognition_state.set_name(face.camera_id, face.tracked_id, face.personName)
        else:
            recognition_state.remove_name(face.camera_id, face.tracked_id)
            if face.tracked_id not in self.old_unknown_id_list:
                self.old_unknown_id_list.append(face.tracked_id)
            else:
                return None

        #tlog("recognize", "***Recognized face***:", face.personName)
        self.recognized_dict[face.tracked_id] = face.personName
        self.sig_face_recognized.emit(face)

        return face

    def process_faces_async(self, faces: List[Face]):
        """Process multiple faces concurrently using new event loop"""
        if not faces:
            return

        # Create tasks for all faces that need recognition
        tasks = []
        semaphore = asyncio.Semaphore(4)
        self._prune_recognized_cooldowns()
        for face in faces:
            face.camera_id = self.camera_config.id
            if self._is_in_recognized_cooldown(face.camera_id, face.tracked_id):
                continue
            #tlog("recognize", "***Add task for face:", face.tracked_id)
            #tlog("recognize", "Ready to convert image")
            face.convert_image()
            #tlog("recognize", "Converted image")
            crop = face.image
            if crop is None:
                continue
            #tlog("recognize", "Crop image:", crop.shape)
            base64_image = image_to_base64(crop)
            if not base64_image:
                continue
            face.base64_image = base64_image
            face.area_id = self.camera_config.areaId
            face.comp_id = self.camera_config.compId
            face.event_type_id = self.camera_config.eventTypeId
            async def _run_with_semaphore(f: Face):
                async with semaphore:
                    return await self.async_recognize_face(f)

            tasks.append(_run_with_semaphore(face))

        if not tasks:
            return

        # Create new event loop for this batch
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)

        try:
            # Execute all recognition tasks concurrently
            #tlog("recognize", f"Processing {len(tasks)} faces concurrently")
            loop.run_until_complete(
                asyncio.gather(*tasks, return_exceptions=True))
        except Exception as e:
            tlog("recognize", f"Error processing faces: {e}")
        finally:
            loop.close()

    def run(self):
        tlog("recognize", "AsyncThreadRecognize started")
        self.__thread_active = True

        while self.__thread_active:
            if self.gather_queue.empty():
                self.msleep(1)
                continue

            faces: List[Face] = self.gather_queue.get()
            self.face_list = faces

            # Process faces asynchronously
            self.process_faces_async(self.face_list)
            if len(self.recognized_dict) > 0:
                self.sig_recognized.emit(self.recognized_dict)
                self.recognized_dict = {}
            self.face_list = []
            self.msleep(1)

        tlog("recognize", "AsyncThreadRecognize stopped")

    def stop(self):
        self.__thread_active = False
        tlog("recognize", "AsyncThreadRecognize stopped")
