import gi
gi.require_version('Gst', '1.0')
from gi.repository import Gst
import pyds
from ..helpers.utils import expand_box
from ..helpers.recognition_state import recognition_state
from ..models import mainConfig


class StreamOutputManager:
    BBOX_EXPAND_RATIO = 0.1

    def __init__(self, pipeline, demux, active_cameras):
        self.pipeline = pipeline
        self.demux = demux
        self.active_cameras = active_cameras
        self.camera_by_index = {camera.index: camera for camera in self.active_cameras}
        self.stream_enabled = bool(getattr(mainConfig, "IS_STREAM", False))
        self._demux_src_pads = {}
        self._stream_branches = {}

    @property
    def requires_stream_branch(self) -> bool:
        return self.stream_enabled

    def setup(self):
        if not self.stream_enabled:
            print("Stream output disabled")
            return
        for camera in self.active_cameras:
            print(f"Media server publish target: {self._build_stream_url(camera)}")

    def attach_camera_branches(self):
        if not self.requires_stream_branch:
            return
        for camera in self.active_cameras:
            self._link_demux_branch(camera.index)

    def shutdown(self):
        return

    def _build_stream_url(self, camera) -> str:
        if camera is None:
            return ""
        base_url = (getattr(mainConfig, "STREAM_URL", "") or "").rstrip("/")
        camera_code = camera.code or camera.name or str(camera.id)
        suffix = f"_{camera.compId}/{camera.areaCode}$${camera_code}"
        return f"{base_url}{suffix}"

    def _expand_bbox_for_output(self, bbox, frame_width: int, frame_height: int):
        expanded_bbox = expand_box(bbox, ratio=self.BBOX_EXPAND_RATIO)
        x1, y1, x2, y2 = expanded_bbox[:4]
        x1 = max(0, min(int(x1), frame_width - 1))
        y1 = max(0, min(int(y1), frame_height - 1))
        x2 = max(x1 + 1, min(int(x2), frame_width))
        y2 = max(y1 + 1, min(int(y2), frame_height))
        return x1, y1, x2, y2

    def _request_mux_video_pad(self, mux):
        sink_pad = mux.request_pad_simple("video")
        if sink_pad is not None:
            return sink_pad
        pad_template = mux.get_pad_template("video")
        if pad_template is None:
            return None
        return mux.request_pad(pad_template, None, None)

    def _build_media_server_branch(self, source_id: int):
        tee = Gst.ElementFactory.make("tee", f"demux-tee-{source_id}")
        queue_stream = Gst.ElementFactory.make("queue", f"stream-queue-{source_id}")
        conv_preosd = Gst.ElementFactory.make("nvvideoconvert", f"stream-conv-preosd-{source_id}")
        caps_preosd = Gst.ElementFactory.make("capsfilter", f"stream-rgba-caps-{source_id}")
        caps_preosd.set_property("caps", Gst.Caps.from_string("video/x-raw(memory:NVMM), format=RGBA"))
        nvosd = Gst.ElementFactory.make("nvdsosd", f"stream-osd-{source_id}")
        conv_postosd = Gst.ElementFactory.make("nvvideoconvert", f"stream-conv-postosd-{source_id}")
        capsfilter = Gst.ElementFactory.make("capsfilter", f"stream-caps-{source_id}")
        capsfilter.set_property("caps", Gst.Caps.from_string("video/x-raw(memory:NVMM), format=I420"))
        enc = Gst.ElementFactory.make("nvv4l2h264enc", f"stream-enc-{source_id}")
        parse = Gst.ElementFactory.make("h264parse", f"stream-parse-{source_id}")
        mux = Gst.ElementFactory.make("flvmux", f"stream-flvmux-{source_id}")
        sink = Gst.ElementFactory.make("rtmpsink", f"stream-sink-{source_id}")

        elements = [
            tee, queue_stream, conv_preosd, caps_preosd, nvosd, conv_postosd, capsfilter, enc, parse, mux, sink,
        ]
        if any(elem is None for elem in elements):
            print(f"Unable to create media-server branch elements for source {source_id}")
            return None

        queue_stream.set_property("max-size-buffers", 4)
        queue_stream.set_property("leaky", 2)

        if nvosd.find_property("process-mode"):
            nvosd.set_property("process-mode", 0)
        if nvosd.find_property("display-text"):
            nvosd.set_property("display-text", 1)
        if enc.find_property("bitrate"):
            enc.set_property("bitrate", 2000000)
        if enc.find_property("maxperf-enable"):
            enc.set_property("maxperf-enable", 1)
        if enc.find_property("insert-sps-pps"):
            enc.set_property("insert-sps-pps", 1)
        if enc.find_property("iframeinterval"):
            enc.set_property("iframeinterval", 15)
        if enc.find_property("idrinterval"):
            enc.set_property("idrinterval", 15)
        if enc.find_property("insert-aud"):
            enc.set_property("insert-aud", 1)
        if parse.find_property("config-interval"):
            parse.set_property("config-interval", 1)
        if mux.find_property("streamable"):
            mux.set_property("streamable", True)
        if sink.find_property("sync"):
            sink.set_property("sync", False)
        if sink.find_property("async"):
            sink.set_property("async", False)

        camera = self.camera_by_index.get(source_id)
        camera_id = camera.id if camera is not None else None
        stream_url = self._build_stream_url(camera)
        if not stream_url:
            print(f"Missing stream URL info for source {source_id}")
            return None
        sink.set_property("location", stream_url)

        for elem in elements:
            self.pipeline.add(elem)

        def _label_probe(pad, info, _):
            gst_buffer = info.get_buffer()
            if not gst_buffer:
                return Gst.PadProbeReturn.OK
            batch_meta = pyds.gst_buffer_get_nvds_batch_meta(hash(gst_buffer))
            if not batch_meta or not batch_meta.frame_meta_list:
                return Gst.PadProbeReturn.OK

            l_frame = batch_meta.frame_meta_list
            while l_frame is not None:
                try:
                    frame_meta = pyds.NvDsFrameMeta.cast(l_frame.data)
                except StopIteration:
                    break

                l_obj = frame_meta.obj_meta_list
                while l_obj is not None:
                    try:
                        obj_meta = pyds.NvDsObjectMeta.cast(l_obj.data)
                    except StopIteration:
                        break

                    object_id = int(obj_meta.object_id)
                    person_name = recognition_state.get_name(camera_id, object_id) if camera_id is not None else None
                    is_recognized = bool(person_name and person_name != "Unknown")
                    label = person_name or "Unknown"
                    x1, y1, x2, y2 = self._expand_bbox_for_output(
                        [
                            obj_meta.rect_params.left,
                            obj_meta.rect_params.top,
                            obj_meta.rect_params.left + obj_meta.rect_params.width,
                            obj_meta.rect_params.top + obj_meta.rect_params.height,
                        ],
                        frame_meta.source_frame_width,
                        frame_meta.source_frame_height,
                    )
                    obj_meta.rect_params.left = x1
                    obj_meta.rect_params.top = y1
                    obj_meta.rect_params.width = x2 - x1
                    obj_meta.rect_params.height = y2 - y1
                    obj_meta.text_params.display_text = label
                    obj_meta.obj_label = label
                    obj_meta.text_params.font_params.font_name = "Serif"
                    obj_meta.text_params.font_params.font_size = 14
                    obj_meta.text_params.set_bg_clr = 1
                    obj_meta.text_params.text_bg_clr.red = 0.0
                    obj_meta.text_params.text_bg_clr.green = 0.0
                    obj_meta.text_params.text_bg_clr.blue = 0.0
                    obj_meta.text_params.text_bg_clr.alpha = 0.7
                    obj_meta.text_params.font_params.font_color.red = 1.0
                    obj_meta.text_params.font_params.font_color.green = 1.0
                    obj_meta.text_params.font_params.font_color.blue = 1.0
                    obj_meta.text_params.font_params.font_color.alpha = 1.0
                    if is_recognized:
                        obj_meta.rect_params.border_color.red = 0.0
                        obj_meta.rect_params.border_color.green = 1.0
                        obj_meta.rect_params.border_color.blue = 0.0
                        obj_meta.rect_params.border_color.alpha = 1.0
                        obj_meta.text_params.text_bg_clr.red = 0.0
                        obj_meta.text_params.text_bg_clr.green = 0.45
                        obj_meta.text_params.text_bg_clr.blue = 0.0
                        obj_meta.text_params.text_bg_clr.alpha = 0.8

                    try:
                        l_obj = l_obj.next
                    except StopIteration:
                        break

                try:
                    l_frame = l_frame.next
                except StopIteration:
                    break
            return Gst.PadProbeReturn.OK

        tee_pad_stream = tee.request_pad(tee.get_pad_template("src_%u"), None, None)
        if tee_pad_stream is None:
            print(f"Unable to request tee pad for source {source_id}")
            return None
        tee_pad_stream.link(queue_stream.get_static_pad("sink"))

        queue_stream.get_static_pad("sink").add_probe(Gst.PadProbeType.BUFFER, _label_probe, None)

        queue_stream.link(conv_preosd)
        conv_preosd.link(caps_preosd)
        caps_preosd.link(nvosd)
        nvosd.link(conv_postosd)
        conv_postosd.link(capsfilter)
        capsfilter.link(enc)
        enc.link(parse)

        sink_pad = self._request_mux_video_pad(mux)
        if sink_pad is None:
            print(f"Unable to request flvmux pad for source {source_id}")
            return None
        if parse.get_static_pad("src").link(sink_pad) != Gst.PadLinkReturn.OK:
            print(f"Failed to link parser to flvmux for source {source_id}")
            return None
        if not mux.link(sink):
            print(f"Failed to link flvmux to rtmpsink for source {source_id}")
            return None

        self._stream_branches[source_id] = {
            "tee": tee,
            "tee_pad_stream": tee_pad_stream,
            "mux_pad": sink_pad,
            "queue": queue_stream,
            "parse": parse,
            "mux": mux,
            "sink": sink,
            "managed_elements": [tee, queue_stream, conv_preosd, caps_preosd, nvosd, conv_postosd, capsfilter, enc, parse, mux, sink],
        }

        return tee

    def _link_demux_branch(self, source_id: int):
        tee = self._build_media_server_branch(source_id)
        if tee is None:
            return

        src_pad = self._demux_src_pads.get(source_id)
        if src_pad is None:
            src_pad = self.demux.request_pad_simple(f"src_{source_id}")
        if src_pad is None:
            print(f"Unable to request demux pad for source {source_id}")
            return
        self._demux_src_pads[source_id] = src_pad
        sink_pad = tee.get_static_pad("sink")
        if src_pad.link(sink_pad) != Gst.PadLinkReturn.OK:
            print(f"Failed to link demux pad for source {source_id}")
        else:
            self._stream_branches[source_id]["demux_src_pad"] = src_pad
            self._stream_branches[source_id]["tee_sink_pad"] = sink_pad
            for element in self._stream_branches[source_id].get("managed_elements", []):
                sync_result = element.sync_state_with_parent()
                if sync_result == Gst.StateChangeReturn.FAILURE:
                    print(
                        f"Failed to sync {element.get_name()} with parent "
                        f"for source {source_id}"
                    )
            self.pipeline.sync_children_states()
            print(f"Linked demux pad for source {source_id}")

    def _remove_camera_branch(self, source_id: int):
        branch = self._stream_branches.get(source_id)
        if branch is None:
            return

        demux_src_pad = branch.get("demux_src_pad")
        tee_sink_pad = branch.get("tee_sink_pad")
        if demux_src_pad is not None and tee_sink_pad is not None:
            demux_src_pad.unlink(tee_sink_pad)

        tee = branch.get("tee")
        tee_pad_stream = branch.get("tee_pad_stream")
        if tee is not None and tee_pad_stream is not None:
            tee.release_request_pad(tee_pad_stream)

        mux = branch.get("mux")
        mux_pad = branch.get("mux_pad")
        parse = branch.get("parse")
        if parse is not None and mux_pad is not None:
            parse_src_pad = parse.get_static_pad("src")
            if parse_src_pad is not None:
                parse_src_pad.unlink(mux_pad)
        if mux is not None and mux_pad is not None:
            mux.release_request_pad(mux_pad)

        sink = branch.get("sink")
        if sink is not None:
            sink.send_event(Gst.Event.new_eos())

        for element in reversed(branch.get("managed_elements", [])):
            element.set_state(Gst.State.NULL)

        for element in branch.get("managed_elements", []):
            try:
                self.pipeline.remove(element)
            except Exception:
                pass

        self._stream_branches.pop(source_id, None)


RtspOutputManager = StreamOutputManager
