import sys
import time
import threading
sys.path.append('../')
import gi
gi.require_version('Gst', '1.0')
from gi.repository import GLib, Gst
import pyds
import cv2
from ..models.param_config import paramConfig
from PyQt5.QtCore import QObject
from ..models import CameraConfig, mainConfig
from typing import Dict, List, Optional
from queue import Queue
from ..helpers.ds import get_surface_from_buffer
from .rtsp_controller import StreamOutputManager

class DeepStreamPipeline(QObject):
    def __init__(self, cameras: List[CameraConfig], dict_queue: Dict[int, Queue]):
        super().__init__()
        self.cameras = cameras
        self.number_sources = len(cameras)
        self.active_cameras: List[CameraConfig] = []
        self.dict_queue = dict_queue
        self.fps_streams = {}
        self.fps_last_times = {}
        self.camera_by_index = {camera.index: camera for camera in cameras}
        self.source_bins: Dict[int, Gst.Bin] = {}
        self.source_sinkpads: Dict[int, Gst.Pad] = {}
        self.source_status: Dict[int, str] = {}
        self.source_retry_counts: Dict[int, int] = {}
        self.source_readd_timers: Dict[int, int] = {}
        self.source_last_activity: Dict[int, float] = {}
        self.source_watchdog_id: Optional[int] = None
        self.live_check_thread: Optional[threading.Thread] = None
        self.live_check_stop = threading.Event()
        self.bus_loop = None


        # GStreamer elements
        self.pipeline = None
        self.streammux = None
        self.pgie = None
        self.tracker = None
        self.tracker_tee = None
        self.nvvidconv1 = None
        self.filter1 = None
        self.tiler = None
        self.sink = None
        self.demux = None

        self.is_live = True
        self.stream_output = None

    def _source_status_for_log(self, source_id: int) -> str:
        return self.source_status.get(source_id, "unknown")

    def _reset_source_counters(self, source_id: int):
        self.source_retry_counts[source_id] = 0
        self.fps_streams.pop(source_id, None)
        self.fps_last_times.pop(source_id, None)

    def _get_source_index_from_element(self, element) -> Optional[int]:
        current = element
        while current is not None:
            name = current.get_name() if hasattr(current, "get_name") else None
            if name and name.startswith("source-bin-"):
                try:
                    return int(name.rsplit("-", 1)[-1])
                except ValueError:
                    return None
            if not hasattr(current, "get_parent"):
                return None
            parent = current.get_parent()
            if parent is current:
                return None
            current = parent
        return None

    def _is_source_message(self, source_id: Optional[int]) -> bool:
        return source_id is not None and source_id in self.camera_by_index

    def _remove_readd_timer(self, source_id: int):
        timer_id = self.source_readd_timers.pop(source_id, None)
        if timer_id:
            GLib.source_remove(timer_id)

    def _mark_source_activity(self, source_id: int):
        self.source_last_activity[source_id] = time.time()

    def _get_source_idle_timeout(self) -> int:
        reconnect_timeout = int(paramConfig.reconnect.interval) * max(1, int(paramConfig.reconnect.attempts))
        return max(15, reconnect_timeout + int(paramConfig.reconnect.readd_delay) + 5)

    def _start_source_watchdog(self):
        if self.source_watchdog_id is not None:
            return
        self.source_watchdog_id = GLib.timeout_add_seconds(5, self._watch_source_activity)

    def _stop_source_watchdog(self):
        if self.source_watchdog_id is None:
            return
        GLib.source_remove(self.source_watchdog_id)
        self.source_watchdog_id = None

    def _watch_source_activity(self):
        idle_timeout = self._get_source_idle_timeout()
        now = time.time()
        for source_id, status in list(self.source_status.items()):
            if status != "active":
                continue
            last_activity = self.source_last_activity.get(source_id)
            if last_activity is None:
                continue
            idle_for = now - last_activity
            if idle_for < idle_timeout:
                continue
            print(
                f"Source {source_id}: no frames for {idle_for:.1f}s "
                f"(threshold={idle_timeout}s), forcing source recycle"
            )
            self._remove_source(source_id, "source idle timeout")
        return True

    def _set_camera_live_flag(self, source_id: int, is_live: bool):
        camera = self.camera_by_index.get(source_id)
        if camera is not None:
            camera.is_live = is_live

    def _release_source_sinkpad(self, source_id: int):
        sinkpad = self.source_sinkpads.pop(source_id, None)
        if sinkpad is None:
            return
        try:
            peer = sinkpad.get_peer()
            if peer is not None:
                peer.unlink(sinkpad)
            sinkpad.send_event(Gst.Event.new_eos())
            sinkpad.send_event(Gst.Event.new_flush_stop(False))
        except Exception as exc:
            print(f"Source {source_id}: failed during sink pad cleanup: {exc}")
        self.streammux.release_request_pad(sinkpad)

    def _register_source(self, source_id: int, source_bin: Gst.Bin, sinkpad: Gst.Pad):
        self.source_bins[source_id] = source_bin
        self.source_sinkpads[source_id] = sinkpad
        self.source_status[source_id] = "active"
        self._reset_source_counters(source_id)
        self._mark_source_activity(source_id)
        self._set_camera_live_flag(source_id, True)

    def _remove_source(self, source_id: int, reason: str):
        self._remove_source_with_policy(source_id, reason, schedule_readd=False)

    def _remove_source_with_policy(self, source_id: int, reason: str, schedule_readd: bool):
        if self.source_status.get(source_id) in {"removing", "waiting_readd"}:
            print(f"Source {source_id}: skip remove while status={self._source_status_for_log(source_id)}")
            return

        source_bin = self.source_bins.get(source_id)
        camera = self.camera_by_index.get(source_id)
        camera_label = camera.id if camera is not None else source_id
        print(f"Source {source_id} ({camera_label}): removing from pipeline. reason={reason}")
        self.source_status[source_id] = "removing"

        if source_bin is not None:
            source_bin.set_state(Gst.State.NULL)

        self._release_source_sinkpad(source_id)

        if source_bin is not None:
            try:
                self.pipeline.remove(source_bin)
            except Exception as exc:
                print(f"Source {source_id}: failed to remove source bin: {exc}")
            self.source_bins.pop(source_id, None)

        self.source_status[source_id] = "waiting_readd" if schedule_readd else "offline"
        self._reset_source_counters(source_id)
        self.source_last_activity.pop(source_id, None)
        if not schedule_readd:
            self._set_camera_live_flag(source_id, False)
        if schedule_readd:
            self._schedule_source_readd(source_id)

    def _set_source_live_state(self, source_id: int, is_live: bool):
        camera = self.camera_by_index.get(source_id)
        if camera is None:
            return False

        if is_live:
            self._remove_readd_timer(source_id)
            if self.source_status.get(source_id) == "active":
                print(f"Source {source_id} ({camera.id}): camera reported live and source is already active")
                return False
            print(f"Source {source_id} ({camera.id}): camera reported live, adding source")
            self._readd_source(source_id)
            return False

        print(f"Source {source_id} ({camera.id}): camera reported offline")
        self._remove_readd_timer(source_id)
        status = self.source_status.get(source_id)
        if status == "active":
            self._remove_source_with_policy(source_id, "camera liveness probe failed", schedule_readd=False)
        else:
            self.source_status[source_id] = "offline"
            self._reset_source_counters(source_id)
            self.source_last_activity.pop(source_id, None)
        return False

    def _probe_camera_live(self, camera: CameraConfig) -> bool:
        capture = None
        try:
            capture = cv2.VideoCapture(camera.rtsp, cv2.CAP_FFMPEG)
            if hasattr(cv2, "CAP_PROP_OPEN_TIMEOUT_MSEC"):
                capture.set(cv2.CAP_PROP_OPEN_TIMEOUT_MSEC, 3000)
            if hasattr(cv2, "CAP_PROP_READ_TIMEOUT_MSEC"):
                capture.set(cv2.CAP_PROP_READ_TIMEOUT_MSEC, 3000)
            if not capture.isOpened():
                return False
            ok, _ = capture.read()
            return bool(ok)
        except Exception as exc:
            print(f"Source {camera.index} ({camera.id}): live probe failed: {exc}")
            return False
        finally:
            if capture is not None:
                capture.release()

    def _start_live_check_thread(self):
        interval = int(getattr(mainConfig, "CHECK_LIVE", 0) or 0)
        if interval <= 0 or self.live_check_thread is not None:
            return

        self.live_check_stop.clear()

        def _worker():
            while not self.live_check_stop.is_set():
                for camera in self.active_cameras:
                    if self.live_check_stop.is_set():
                        return
                    if camera.is_live:
                        continue
                    is_live = self._probe_camera_live(camera)
                    if camera.is_live == is_live:
                        continue
                    camera.is_live = is_live
                    state_label = "live" if is_live else "offline"
                    print(f"Source {camera.index} ({camera.id}): liveness changed -> {state_label}")
                    GLib.idle_add(self._set_source_live_state, camera.index, is_live)
                if self.live_check_stop.wait(interval):
                    return

        self.live_check_thread = threading.Thread(
            target=_worker,
            name="camera-live-check",
            daemon=True,
        )
        self.live_check_thread.start()

    def _stop_live_check_thread(self):
        if self.live_check_thread is None:
            return
        self.live_check_stop.set()
        self.live_check_thread.join(timeout=2)
        self.live_check_thread = None

    def _schedule_source_readd(self, source_id: int):
        self._remove_readd_timer(source_id)
        delay = max(1, int(paramConfig.reconnect.readd_delay))
        print(f"Source {source_id}: scheduling re-add in {delay}s")
        timer_id = GLib.timeout_add_seconds(delay, self._readd_source, source_id)
        self.source_readd_timers[source_id] = timer_id

    def _readd_source(self, source_id: int):
        self.source_readd_timers.pop(source_id, None)
        camera = self.camera_by_index.get(source_id)
        if camera is None:
            print(f"Source {source_id}: camera config missing, cannot re-add")
            self.source_status[source_id] = "missing"
            return False
        if self.pipeline is None or self.streammux is None:
            print(f"Source {source_id}: pipeline not ready, skip re-add")
            self.source_status[source_id] = "pipeline_missing"
            return False
        if source_id in self.source_bins:
            print(f"Source {source_id}: source already present, skip re-add")
            self.source_status[source_id] = "active"
            return False

        print(f"Source {source_id} ({camera.id}): re-adding source bin")
        source_bin = self.create_source_bin(source_id, camera)
        if source_bin is None:
            print(f"Source {source_id}: failed to create source bin, rescheduling")
            self.source_status[source_id] = "waiting_readd"
            self._schedule_source_readd(source_id)
            return False

        self.pipeline.add(source_bin)
        sinkpad = self.streammux.request_pad_simple(f"sink_{source_id}")
        if sinkpad is None:
            print(f"Source {source_id}: failed to request streammux sink pad, rescheduling")
            self.pipeline.remove(source_bin)
            source_bin.set_state(Gst.State.NULL)
            self.source_status[source_id] = "waiting_readd"
            self._schedule_source_readd(source_id)
            return False

        srcpad = source_bin.get_static_pad("src")
        if srcpad is None or srcpad.link(sinkpad) != Gst.PadLinkReturn.OK:
            print(f"Source {source_id}: failed to relink source bin, rescheduling")
            self.streammux.release_request_pad(sinkpad)
            self.pipeline.remove(source_bin)
            source_bin.set_state(Gst.State.NULL)
            self.source_status[source_id] = "waiting_readd"
            self._schedule_source_readd(source_id)
            return False

        sync_result = source_bin.sync_state_with_parent()
        source_bin.set_state(Gst.State.PLAYING)
        print(f"Source {source_id}: sync_state_with_parent={sync_result}")
        self._register_source(source_id, source_bin, sinkpad)
        return False

    def _handle_source_error(self, source_id: int, error_message: str, debug_message: str):
        status = self.source_status.get(source_id)
        if status != "active":
            print(f"Source {source_id}: ignore error while status={self._source_status_for_log(source_id)}")
            return

        self.source_retry_counts[source_id] = self.source_retry_counts.get(source_id, 0) + 1
        attempts = max(1, int(paramConfig.reconnect.attempts))
        print(
            f"Source {source_id}: terminal source error after reconnect attempts "
            f"({self.source_retry_counts[source_id]}/{attempts}) -> {error_message} | {debug_message}"
        )
        self._remove_source(source_id, error_message)

    def _is_valid_uri(self, uri: str) -> bool:
        if not uri:
            return False
        return uri.startswith("rtsp://") or uri.startswith("rtmp://")

    def tiler_sink_pad_buffer_probe(self, pad, info, u_data):
        gst_buffer = info.get_buffer()
        if not gst_buffer:
            print("Unable to get GstBuffer ")
            return Gst.PadProbeReturn.OK

        batch_meta = pyds.gst_buffer_get_nvds_batch_meta(hash(gst_buffer))
        l_frame = batch_meta.frame_meta_list
        while l_frame is not None:
            try:
                frame_meta = pyds.NvDsFrameMeta.cast(l_frame.data)
            except StopIteration:
                break

            tracked_dict = {}
            l_obj = frame_meta.obj_meta_list
            while l_obj is not None:
                obj_meta = pyds.NvDsObjectMeta.cast(l_obj.data)
                if paramConfig.model.min_confidence <= obj_meta.confidence <= paramConfig.model.max_confidence:
                    rect = obj_meta.rect_params
                    tracked_dict[int(obj_meta.object_id)] = [
                        int(rect.left),
                        int(rect.top),
                        int(min(rect.left + rect.width, frame_meta.source_frame_width)),
                        int(min(rect.top + rect.height, frame_meta.source_frame_height)),
                        float(obj_meta.confidence),
                        int(obj_meta.class_id),
                    ]
                l_obj = l_obj.next

            surface = get_surface_from_buffer(gst_buffer, frame_meta.batch_id)
            self._mark_source_activity(frame_meta.pad_index)
            queue_ref = self.dict_queue.get(frame_meta.pad_index)
            if queue_ref is not None and queue_ref.empty():
                queue_ref.put([surface, tracked_dict])
            try:
                l_frame = l_frame.next
            except StopIteration:
                break

        return Gst.PadProbeReturn.OK

    def print_fps(self, stream_index, cur_frame_num):
        t = time.time()
        if stream_index not in self.fps_streams:
            self.fps_streams[stream_index] = {'last_frame': 0, 'last_time': t, 'fps': 0.0}
            self.fps_last_times[stream_index] = t
            return
        elapsed = t - self.fps_streams[stream_index]['last_time']
        if elapsed >= 1.0:
            frames = cur_frame_num - self.fps_streams[stream_index]['last_frame']
            fps = frames / elapsed
            self.fps_streams[stream_index]['fps'] = fps
            self.fps_streams[stream_index]['last_frame'] = cur_frame_num
            self.fps_streams[stream_index]['last_time'] = t
            print(f"DS {stream_index}: FPS={fps:.2f}")
        self.fps_last_times[stream_index] = t

    def bus_call(self, bus, message, loop):
        t = message.type
        if t == Gst.MessageType.EOS:
            source_id = self._get_source_index_from_element(message.src)
            if self._is_source_message(source_id):
                print(f"Source {source_id}: EOS received")
            else:
                print("End-of-stream\n")
        elif t == Gst.MessageType.WARNING:
            err, debug = message.parse_warning()
            print("Warning: %s: %s\n" % (err, debug))
        elif t == Gst.MessageType.ERROR:
            err, debug = message.parse_error()
            source_id = self._get_source_index_from_element(message.src)
            if self._is_source_message(source_id):
                self._handle_source_error(source_id, str(err), debug or "")
            else:
                print("Error: %s: %s\n" % (err, debug))
        elif t == Gst.MessageType.STATE_CHANGED:
            # Log state changes để debug
            if message.src == self.pipeline:
                old_state, new_state, pending_state = message.parse_state_changed()
                print(f"Pipeline state changed: {old_state.value_nick} -> {new_state.value_nick}")
        return True


    def cb_newpad(self, decodebin, decoder_src_pad, data):
        print("In cb_newpad")
        source_bin = data

        bin_ghost_pad = source_bin.get_static_pad("src")
        if not bin_ghost_pad:
            print("Failed to get ghost pad\n")
            return

        if bin_ghost_pad.get_target():
            print("Ghost pad already linked, ignoring additional pad")
            return

        if not bin_ghost_pad.set_target(decoder_src_pad):
            print("Failed to link decoder src pad to source bin ghost pad\n")
            return

        print(f"Successfully linked source bin ghost pad to decoder src pad")

        caps = decoder_src_pad.get_current_caps()
        if caps:
            gststruct = caps.get_structure(0)
            if gststruct:
                gstname = gststruct.get_name()
                features = caps.get_features(0)
                print(f"  Pad caps: {gstname}, features: {features.to_string()}")

    def decodebin_child_added(self, child_proxy, Object, name, user_data):
        print("Decodebin child added:", name, "\n")
        if name.find("decodebin") != -1:
            Object.connect("child-added", self.decodebin_child_added, user_data)

        if name.find("nvv4l2decoder") != -1:
            Object.set_property("cudadec-memtype", 2)

        if "source" in name:
            source_element = child_proxy.get_by_name("source")
            if source_element.find_property('drop-on-latency') != None:
                Object.set_property("drop-on-latency", True)

    def create_source_bin(self, index, camera: CameraConfig):
        print(f"Creating source bin {index} for URI: {camera.rtsp}")

        bin_name = f"source-bin-{index}"
        nbin = Gst.Bin.new(bin_name)
        if not nbin:
            print("Unable to create source bin\n")
            return None

        uri_decode_bin = Gst.ElementFactory.make("nvurisrcbin", f"uri-decode-bin-{index}")
        if not uri_decode_bin:
            print("Unable to create nvurisrcbin\n")
            return None

        uri_decode_bin.set_property("uri", camera.rtsp)

        uri_decode_bin.set_property("rtsp-reconnect-interval", paramConfig.reconnect.interval)       # Reconnect every 5 seconds
        uri_decode_bin.set_property("rtsp-reconnect-attempts", paramConfig.reconnect.attempts)      # -1 = infinite reconnect attempts
        uri_decode_bin.set_property("drop-on-latency", paramConfig.reconnect.drop_on_latency)            # Drop frames on high latency


        print(f"  Configured reconnect: interval={paramConfig.reconnect.interval}s, attempts={paramConfig.reconnect.attempts}")

        # Bind the callback with self using lambda to capture self for method
        uri_decode_bin.connect("pad-added", lambda db, decoder_src_pad, data: self.cb_newpad(db, decoder_src_pad, data), nbin)

        Gst.Bin.add(nbin, uri_decode_bin)

        ghost_pad = Gst.GhostPad.new_no_target("src", Gst.PadDirection.SRC)
        if not ghost_pad:
            print("Failed to create ghost pad\n")
            return None

        ghost_pad.set_active(True)
        if not nbin.add_pad(ghost_pad):
            print("Failed to add ghost pad to bin\n")
            return None

        return nbin

    def build_pipeline(self):
        Gst.init(None)

        print("Creating Pipeline \n ")
        self.pipeline = Gst.Pipeline()
        self.is_live = False
        self.active_cameras = [c for c in self.cameras if self._is_valid_uri(c.rtsp)]
        self.number_sources = len(self.active_cameras)
        self.stream_output = StreamOutputManager(self.pipeline, None, self.active_cameras)
        for camera in self.cameras:
            if not self._is_valid_uri(camera.rtsp):
                print(f"Skipping camera {camera.id} due to invalid RTSP: {camera.rtsp}")
        if self.number_sources == 0:
            print("No valid RTSP sources. Pipeline will not start.")
            return False

        if not self.pipeline:
            print(" Unable to create Pipeline \n")
        print("Creating streamux \n ")

        self.streammux = Gst.ElementFactory.make("nvstreammux", "Stream-muxer")
        if not self.streammux:
            print(" Unable to create NvStreamMux \n")

        self.pipeline.add(self.streammux)
        for camera in self.active_cameras:
            print("Creating source_bin ", camera.index, " \n ")
            self.is_live = True
            source_bin = self.create_source_bin(camera.index, camera)
            if not source_bin:
                print("Unable to create source bin \n")
            self.pipeline.add(source_bin)
            padname = f"sink_{camera.index}"
            sinkpad = self.streammux.request_pad_simple(padname)
            if not sinkpad:
                print("Unable to create sink pad bin \n")
            srcpad = source_bin.get_static_pad("src")
            if not srcpad:
                print("Unable to create src pad bin \n")
            elif srcpad.link(sinkpad) != Gst.PadLinkReturn.OK:
                print("Failed to link source bin to streammux")
            else:
                self._register_source(camera.index, source_bin, sinkpad)
        print("Creating Pgie (YOLO) \n ")
        self.pgie = Gst.ElementFactory.make("nvinfer", "primary-inference")
        if not self.pgie:
            print(" Unable to create pgie \n")
        
        print("Creating Tracker \n ")
        self.tracker = Gst.ElementFactory.make("nvtracker", "tracker")
        if not self.tracker:
            print(" Unable to create tracker \n")

        if self.stream_output.requires_stream_branch:
            print("Creating tracker tee \n ")
            self.tracker_tee = Gst.ElementFactory.make("tee", "tracker-tee")
            if not self.tracker_tee:
                print(" Unable to create tracker tee \n")
                return False

        print("Creating nvvidconv1 \n ")
        self.nvvidconv1 = Gst.ElementFactory.make("nvvideoconvert", "convertor1")
        if not self.nvvidconv1:
            print(" Unable to create nvvidconv1 \n")

        print("Creating filter1 \n ")
        self.filter1 = Gst.ElementFactory.make("capsfilter", "filter1")
        if not self.filter1:
            print(" Unable to create filter1 \n")
        self.filter1.set_property("caps", Gst.Caps.from_string("video/x-raw(memory:NVMM), format=RGBA"))

        print("Creating tiler \n ")
        self.tiler = Gst.ElementFactory.make("nvmultistreamtiler", "nvtiler")
        if not self.tiler:
            print(" Unable to create tiler \n")

        print("Creating fakesink \n ")
        self.sink = Gst.ElementFactory.make("fakesink", "fakesink")
        if not self.sink:
            print(" Unable to create fakesink \n")
        self.sink.set_property("sync", 0)
        
        if self.stream_output.requires_stream_branch:
            print("Creating demux \n ")
            self.demux = Gst.ElementFactory.make("nvstreamdemux", "stream-demuxer")
            if not self.demux:
                print(" Unable to create demux \n")
                return False
            self.stream_output.demux = self.demux

        if self.is_live:
            print("At least one of the sources is live")
            self.streammux.set_property('live-source', 1)

        self.streammux.set_property('width', paramConfig.streammux.width)
        self.streammux.set_property('height', paramConfig.streammux.height)
        
        # Override batch-size to match number of sources if needed
        config_batch_size = paramConfig.streammux.batch_size
        if config_batch_size < self.number_sources:
            print(f"WARNING: Overriding streammux batch-size {config_batch_size} with number of sources {self.number_sources}")
            self.streammux.set_property('batch-size', self.number_sources)
        else:
            self.streammux.set_property('batch-size', config_batch_size)
        
        self.streammux.set_property('batched-push-timeout', paramConfig.streammux.batched_push_timeout)
        self.pgie.set_property('config-file-path', paramConfig.streammux.config_file_path)
        pgie_batch_size = self.pgie.get_property("batch-size")
        if (pgie_batch_size != self.number_sources):
            print("WARNING: Overriding infer-config batch-size", pgie_batch_size, " with number of sources ",
                  self.number_sources, " \n")
            self.pgie.set_property("batch-size", self.number_sources)
        
        config_tracker = {
            'tracker-width': paramConfig.tracker.tracker_width,
            'tracker-height': paramConfig.tracker.tracker_height,
            'gpu-id': paramConfig.tracker.gpu_id,
            'll-lib-file': paramConfig.tracker.ll_lib_file,
            'll-config-file': paramConfig.tracker.ll_config_file
        }

        for key, value in config_tracker.items():
            self.tracker.set_property(key, value)
        print(f"Tracker configured: width={paramConfig.tracker.tracker_width}, height={paramConfig.tracker.tracker_height}")
        
        # set memory type to CUDA Unified
        mem_type = int(pyds.NVBUF_MEM_CUDA_UNIFIED)
        self.streammux.set_property("nvbuf-memory-type", mem_type)
        self.nvvidconv1.set_property("nvbuf-memory-type", mem_type)
        self.tiler.set_property("nvbuf-memory-type", mem_type)

        print("Adding elements to Pipeline \n")
        self.pipeline.add(self.pgie)
        self.pipeline.add(self.tracker)
        if self.tracker_tee is not None:
            self.pipeline.add(self.tracker_tee)
        self.pipeline.add(self.nvvidconv1)
        self.pipeline.add(self.filter1)
        self.pipeline.add(self.tiler)
        self.pipeline.add(self.sink)
        if self.demux is not None:
            self.pipeline.add(self.demux)

        print("Linking elements in the Pipeline \n")
        if not self.streammux.link(self.pgie):
            print("Failed to link streammux to pgie")
        if not self.pgie.link(self.tracker):
            print("Failed to link pgie to tracker")
        if self.stream_output.requires_stream_branch:
            if not self.tracker.link(self.tracker_tee):
                print("Failed to link tracker to tracker tee")
                return False
            tee_pad_main = self.tracker_tee.request_pad(self.tracker_tee.get_pad_template("src_%u"), None, None)
            tee_pad_stream = self.tracker_tee.request_pad(self.tracker_tee.get_pad_template("src_%u"), None, None)
            if tee_pad_main is None or tee_pad_stream is None:
                print("Failed to request tracker tee pads")
                return False
            if tee_pad_main.link(self.nvvidconv1.get_static_pad("sink")) != Gst.PadLinkReturn.OK:
                print("Failed to link tracker tee to main branch")
                return False
            if tee_pad_stream.link(self.demux.get_static_pad("sink")) != Gst.PadLinkReturn.OK:
                print("Failed to link tracker tee to demux")
                return False
        else:
            if not self.tracker.link(self.nvvidconv1):
                print("Failed to link tracker to main branch")
                return False

        if not self.nvvidconv1.link(self.filter1):
            print("Failed to link nvvidconv1 to filter1")
        if not self.filter1.link(self.tiler):
            print("Failed to link filter1 to tiler")
        if not self.tiler.link(self.sink):
            print("Failed to link tiler to sink")
        self.stream_output.attach_camera_branches()
        self.stream_output.setup()
        return True

    def run(self):
        if self.build_pipeline() is False:
            return
        loop = GLib.MainLoop()
        self.bus_loop = loop
        bus = self.pipeline.get_bus()
        bus.add_signal_watch()
        bus.connect("message", self.bus_call, loop)

        tiler_sink_pad = self.tiler.get_static_pad("sink")
        if not tiler_sink_pad:
            print(" Unable to get tiler sink pad \n")
        else:
            tiler_sink_pad.add_probe(
                Gst.PadProbeType.BUFFER,
                lambda pad, info, u_data: self.tiler_sink_pad_buffer_probe(pad, info, u_data),
                None,
            )

        print("Now playing...")
        for camera in self.active_cameras:
            print(f"Source {camera.index}: {camera.id}")

        print("Starting pipeline \n")
        self.pipeline.set_state(Gst.State.PLAYING)
        self._start_source_watchdog()
        self._start_live_check_thread()
        try:
            loop.run()
        except Exception as e:
            print(f"Error in main: {e}")
            pass
        print("Exiting app\n")
        self._stop_live_check_thread()
        self._stop_source_watchdog()
        for source_id in list(self.source_readd_timers):
            self._remove_readd_timer(source_id)
        self.pipeline.set_state(Gst.State.NULL)
        if self.stream_output is not None:
            self.stream_output.shutdown()
