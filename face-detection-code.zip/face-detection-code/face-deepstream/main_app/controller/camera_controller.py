from PyQt5 import QtCore
from ..threads import ThreadConsumer, ThreadGather, AsyncThreadRecognize, ThreadEvent
from ..models import CameraConfig
from queue import Queue
from typing import List, Optional
from ..helpers.log import tlog


class Camera(QtCore.QObject):
    def __init__(self, parent=None, camera_config: Optional[CameraConfig] = None, tracking_queue: Queue = None):
        super().__init__(parent)
        self.camera_config = camera_config
        self.list_threads: List[QtCore.QThread] = []
        self.tracking_queue = tracking_queue
        tlog("capture", "Config:", self.camera_config.name)

        self.setup_queue()
        self.setup_thread()
        self.connect_signal()

    def setup_queue(self):
        self.consumer_queue = Queue(maxsize=1)
        self.gather_queue = Queue(maxsize=10)

    def setup_thread(self):
        self.thread_consumer = ThreadConsumer(
            self, self.camera_config, self.tracking_queue, self.consumer_queue)
        self.thread_gather = ThreadGather(
            self.consumer_queue, self.gather_queue)
        self.thread_recognize = AsyncThreadRecognize(
            self, self.gather_queue, self.camera_config)
        self.thread_event = ThreadEvent(self)

        self.list_threads = [
            self.thread_consumer, self.thread_gather, self.thread_recognize,
            self.thread_event,
        ]

    def connect_signal(self):
        self.thread_recognize.sig_face_recognized.connect(self.thread_event.on_face_recognized)

    def start(self):
        for thread in self.list_threads:
            thread.start()

    def stop(self):
        for thread in self.list_threads:
            thread.stop()
