import time
from PyQt5 import QtCore
from .camera_controller import Camera
from .ds_controller import DeepStreamPipeline
from ..models import CameraConfig, accessToken, mainConfig
from ..services.api import get_config_from_api
from ..threads.thread_token import ThreadToken
from typing import List, Dict
from queue import Queue
from ..helpers.log import tlog

class MainController(QtCore.QObject):

    def __init__(self, parent=None):
        super().__init__(parent)
        self.cameras_config: List[CameraConfig] = []
        self.dict_camera: Dict[int, Camera] = {}
        # create ds controller
        self.dict_queue: Dict[int, Queue] = {}

        self.setup_thread()

        self.set_config_from_api()
        self.create_camera_from_config()

        self.ds_controller = DeepStreamPipeline(self.cameras_config, dict_queue=self.dict_queue)

    def setup_thread(self):
        self.thread_token = ThreadToken()
        self.thread_token.start()


    # get config from api and set to list_config
    def set_config_from_api(self):
        while True:
            if not accessToken.value:
                tlog("token", "Waiting token")
                time.sleep(1)
                continue
            break
        result = get_config_from_api(mainConfig.URL_CONFIG)
        for index, device in enumerate(result):
            camera_config = CameraConfig()
            camera_config.set_config(index, device)
            if camera_config.id is None or not camera_config.rtsp:
                continue
            if mainConfig.SERVER_ID and str(camera_config.serverId) != str(mainConfig.SERVER_ID):
                continue
            if mainConfig.FACE_FEATURE_ID and str(camera_config.lstFeature) != str(mainConfig.FACE_FEATURE_ID):
                continue
            if mainConfig.AREA_CODE_ALLOW and camera_config.areaCode != mainConfig.AREA_CODE_ALLOW:
                continue
            self.cameras_config.append(camera_config)

    def create_camera_from_config(self):
        for idx, config in enumerate(self.cameras_config):
            tlog("capture", "Create camera:", config.id)
            self.create_camera(config)

    # create camera
    def create_camera(self, config: CameraConfig):
        self.dict_queue[config.index] = Queue()
        camera = Camera(camera_config=config, tracking_queue=self.dict_queue[config.index])
        self.dict_camera[config.id] = camera

    # start camera
    def start_camera(self):
        for key, camera in self.dict_camera.items():
            camera.start()

    # stop camera

    def stop_camera(self):
        for camera in self.dict_camera:
            camera.stop()

    def start_pipeline(self):
        self.start_camera()
        self.ds_controller.run()

    def stop_pipeline(self):
        self.stop_camera()
