from dataclasses import dataclass
import time
import cv2
from ..helpers.ds import get_frame_from_buffer
from ..helpers.utils import expand_box
from datetime import datetime
from typing import Optional
import uuid

@dataclass
class Face:
    UNKNOWN_PERSON_ID: str = "00000000-0000-0000-0000-000000000000"
    uuid: Optional[str] = None
    init_time: Optional[float] = None
    confidence: Optional[float] = None
    tracked_id: Optional[int] = None
    personName: Optional[str] = None
    surface: Optional[object] = None
    bbox: Optional[list] = None
    image: Optional[object] = None
    personId: Optional[str] = None
    quality: Optional[float] = None
    faceFeature: Optional[str] = None
    scoreMatching: Optional[float] = None
    camera_id: Optional[int] = None
    area_id: Optional[int] = None
    comp_id: Optional[int] = None
    event_type_id: Optional[int] = None
    base64_image: Optional[str] = None

    def __post_init__(self):
        self.uuid = str(uuid.uuid4())
        self.init_time = time.time()
    
    def convert_image(self):
        if self.surface is None or not self.bbox:
            return
        frame = get_frame_from_buffer(self.surface)
        if frame is None:
            return
        frame = cv2.cvtColor(frame, cv2.COLOR_RGBA2BGR)
        bbox = expand_box(self.bbox, ratio=0.2)
        h, w = frame.shape[:2]
        x1 = max(0, min(int(bbox[0]), w - 1))
        y1 = max(0, min(int(bbox[1]), h - 1))
        x2 = max(0, min(int(bbox[2]), w))
        y2 = max(0, min(int(bbox[3]), h))
        if x2 <= x1 or y2 <= y1:
            return
        crop = frame[y1:y2, x1:x2]
        if crop is None or crop.size == 0:
            return
        self.image = crop

    def handle_response(self, res):
        data = res.get("data") if isinstance(res, dict) else None
        if not data:
            self.set_unknown_person()
            return
        input_data = data.get("input_data", {})
        self.faceFeature = input_data.get("featureBase64")
        self.quality = input_data.get("quality")
        result = data.get("result") or []
        if result:
            self.personId = result[0]["personId"]
            self.personName = result[0]["fullname"]
            self.scoreMatching = result[0]["scoreMatching"]
        else:
            self.set_unknown_person()

    def set_unknown_person(self):
        self.personId = self.UNKNOWN_PERSON_ID
        self.personName = "Unknown"

    @property 
    def payload(self):
        return {
            "eventId": self.uuid,
            "personID": self.personId,
            "featurePath": self.faceFeature,
            "ImageBase64": self.base64_image,
            "age": 0,
            "gender": 0,
            "deviceId": self.camera_id,
            "areaId": self.area_id,
            "compId": self.comp_id,
            "accessDate": datetime.fromtimestamp(self.init_time).strftime("%Y-%m-%d"),
            "accessTime": datetime.fromtimestamp(self.init_time).strftime("%Y-%m-%d %H:%M:%S"),
            "facePath": "",
            "status": 0,
            "scoreMatch": 0 if not self.scoreMatching else self.scoreMatching,
            "similarPersonId": self.UNKNOWN_PERSON_ID,
            "eventTypeId": self.event_type_id,
        }
    
    @property
    def is_unknown(self):
        return self.personName == "Unknown"
