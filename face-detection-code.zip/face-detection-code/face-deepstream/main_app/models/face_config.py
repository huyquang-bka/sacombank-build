from dataclasses import dataclass
import yaml

@dataclass
class FaceConfig:
    URL_RECOGNIZE_FACE_ARC: str
    HEADER_RECOGNIZE_FACE_ARC: dict
    PAYLOAD_RECOGNIZE_FACE_ARC: dict
    TIME_LIMIT_PER_ID: int
    RECOGNIZE_STATE_TIME: int
    NUM_FACE_PER_ID: int

    def __init__(self):
        with open("resources/face.yaml", "r") as f:
            config = yaml.safe_load(f)
            for key, value in config.items():
                setattr(self, key, value)

faceConfig = FaceConfig()
