from dataclasses import dataclass


@dataclass
class Token:
    value: str = None
    id_company: str = 1

    def __str__(self):
        return "Token: " + self.value


accessToken = Token()
