import yaml
from dataclasses import dataclass

@dataclass
class ModelConfig:
    min_confidence: float
    max_confidence: float
    class_id: list

@dataclass
class TrackerConfig:
    tracker_width: int
    tracker_height: int
    gpu_id: int
    ll_lib_file: str
    ll_config_file: str

@dataclass
class TrackerConfig:
    tracker_width: int
    tracker_height: int
    gpu_id: int
    ll_lib_file: str
    ll_config_file: str

@dataclass
class ReconnectConfig:
    interval: int
    attempts: int
    drop_on_latency: bool
    readd_delay: int

@dataclass
class StreamMuxConfig:
    width: int
    height: int
    batch_size: int
    batched_push_timeout: int
    config_file_path: str

@dataclass
class ParamConfig:
    model: ModelConfig
    tracker: TrackerConfig
    reconnect: ReconnectConfig
    streammux: StreamMuxConfig

def load_param_config(config_path: str) -> ParamConfig:
    with open(config_path, 'r') as file:
        config = yaml.safe_load(file)
    return ParamConfig(
        model=ModelConfig(**config['model']),
        tracker=TrackerConfig(**config['tracker']),
        reconnect=ReconnectConfig(**config['reconnect']),
        streammux=StreamMuxConfig(**config['streammux'])
    )

paramConfig = load_param_config("resources/param_config.yaml")
if __name__ == "__main__":
    for key, value in paramConfig.tracker.__dict__.items():
        print(key, value)
