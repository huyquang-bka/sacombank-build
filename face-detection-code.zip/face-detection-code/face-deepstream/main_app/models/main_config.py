from dataclasses import dataclass, asdict
import os
import yaml


@dataclass
class MainConfig:
    """Config for main app"""
    # URL
    BASE_HOST: str = None
    URI: str = None

    URI_CONFIG: str = None
    URI_FACE: str = None
    URI_TOKEN: str = None

    # Payload
    PAYLOAD_TOKEN: dict = None

    # Time
    TIMEOUT: int = None
    TIME_TOKEN: int = None
    OVERLAP_TIME: int = None
    TIME_TO_GET_CAM: int = None
    CHECK_LIVE: int = None

    # Server
    LOCAL_STORAGE: str = None

    # Face feature id
    FACE_FEATURE_ID: str = None

    # Area filter
    AREA_CODE_ALLOW: str = None
    SERVER_ID: str = None

    # Stream
    IS_STREAM: bool = None
    STREAM_URL: str = None
    STREAM_SIZE: list = None

    def __post_init__(self):
        with open('resources/configs/main.yaml') as f:
            data = yaml.load(f, Loader=yaml.FullLoader)
        for key, value in data.items():
            setattr(self, key, value)
        self.AREA_CODE_ALLOW = os.environ.get("AREA_CODE") or os.environ.get("AREA_CODE_ALLOW")
        self.SERVER_ID = os.environ.get("SERVER_ID")
        self.URL = self.BASE_HOST + self.URI
        self.URL_CONFIG = self.BASE_HOST + self.URI_CONFIG
        self.URL_FACE = self.BASE_HOST + self.URI_FACE
        self.URL_TOKEN = self.BASE_HOST + self.URI_TOKEN

    def __str__(self) -> str:
        return str(asdict(self))


mainConfig = MainConfig()
