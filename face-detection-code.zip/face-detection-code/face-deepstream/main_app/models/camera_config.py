from dataclasses import dataclass
import json
from typing import Any, Dict, List, Optional
from urllib.parse import quote, unquote, urlsplit, urlunsplit


def normalize_rtsp_url(url: Optional[str]) -> Optional[str]:
    """Percent-encode RTSP credentials for GStreamer compatibility."""
    if not url or "://" not in url:
        return url
    try:
        parsed = urlsplit(url)
    except ValueError:
        return url
    if parsed.scheme.lower() != "rtsp" or parsed.hostname is None:
        return url
    if parsed.username is None and parsed.password is None:
        return url

    username = quote(unquote(parsed.username or ""), safe="")
    password = quote(unquote(parsed.password or ""), safe="")
    hostname = parsed.hostname
    if ":" in hostname and not hostname.startswith("["):
        hostname = f"[{hostname}]"

    userinfo = username
    if parsed.password is not None:
        userinfo = f"{userinfo}:{password}"

    netloc = f"{userinfo}@{hostname}"
    if parsed.port is not None:
        netloc = f"{netloc}:{parsed.port}"

    return urlunsplit((
        parsed.scheme,
        netloc,
        parsed.path,
        parsed.query,
        parsed.fragment,
    ))


@dataclass()
class CameraConfig:
    """Config mapped from camera payload."""
    index: Optional[int] = None
    id: Optional[str] = None
    name: Optional[str] = None
    code: Optional[str] = None
    rtsp: Optional[str] = None
    polygon: Optional[List[List[int]]] = None
    compName: Optional[str] = None
    compId: Optional[int] = None
    serverId: Optional[int] = None
    areaId: Optional[int] = None
    areaCode: Optional[str] = None
    eventTypeId: Optional[int] = None
    lstFeature: Optional[str] = None
    is_live: bool = True
    stream_enabled: bool = True

    def set_config(self, index: int, config: Dict[str, Any]):
        """Populate config from camera payload."""
        self.index = index
        if "rstpLink" in config or "deviceCode" in config or "deviceName" in config:
            self._set_from_web_api(config)
        elif "link" in config:
            self._set_from_face_config(config)
        else:
            self._set_from_generic(config)
        self.rtsp = normalize_rtsp_url(self.rtsp)

    def _set_from_generic(self, config: Dict[str, Any]):
        """Map generic camera payload to internal attributes."""
        self.id = config.get("id")
        self.name = config.get("name")
        self.code = config.get("name") or config.get("id")
        self.compId = config.get("compId")
        self.serverId = config.get("serverId") or config.get("serverID")
        self.compName = (
            self.compId
            or config.get("compName")
            or config.get("parameters", {}).get("customGroupId")
            or config.get("customGroupId")
            or "Unknown"
        )
        self.areaId = config.get("areaId")
        self.areaCode = config.get("areaCode")
        self.eventTypeId = config.get("eventTypeId")
        self.lstFeature = config.get("lstFeature")
        self.polygon = (
            config.get("polygon")
            or config.get("parameters", {}).get("polygon")
        )
        self.rtsp = config.get("link") or config.get("rtsp") or config.get("url")

    def _set_from_face_config(self, config: Dict[str, Any]):
        """Map face-detection-reference camera payload."""
        self.id = config.get("id")
        self.name = config.get("name")
        self.code = config.get("code") or config.get("name") or str(config.get("id"))
        self.compId = config.get("compId")
        self.serverId = config.get("serverId") or config.get("serverID")
        self.compName = self.compId
        self.areaId = config.get("areaId")
        self.areaCode = config.get("areaCode")
        self.eventTypeId = config.get("eventTypeId")
        self.lstFeature = config.get("lstFeature")
        self.polygon = None
        self.rtsp = config.get("link")

    def _set_from_web_api(self, config: Dict[str, Any]):
        """Map local web API camera payload used by face-detection."""
        self.id = config.get("id")
        self.name = config.get("deviceName") or config.get("name")
        self.code = config.get("deviceCode") or config.get("code") or str(config.get("id"))
        self.compId = config.get("compId")
        self.serverId = config.get("serverId") or config.get("serverID")
        self.compName = self.compId or config.get("compName") or "Unknown"
        self.areaId = config.get("areaId")
        self.areaCode = config.get("areaCode")
        self.eventTypeId = config.get("eventTypeId")
        self.lstFeature = config.get("lstFeature")
        self.polygon = config.get("polygon")
        self.rtsp = config.get("rstpLink") or config.get("link") or config.get("rtsp")

    def __str__(self):
        return json.dumps(self.__dict__, indent=4, sort_keys=True)
