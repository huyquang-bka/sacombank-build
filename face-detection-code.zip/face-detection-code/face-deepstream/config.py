import os
from os.path import dirname

ROOT = dirname(dirname(os.path.abspath(__file__)))

if __name__ == "__main__":
    print(ROOT)