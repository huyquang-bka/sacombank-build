import sys
import signal
from main_app.controller.main_controller import MainController
from PyQt5 import QtCore

if __name__ == "__main__":
    app = QtCore.QCoreApplication(sys.argv)
    signal.signal(signal.SIGINT, signal.SIG_DFL)
    main_controller = MainController()
    main_controller.start_pipeline()
    sys.exit(app.exec_())